// PWA Service Worker Registration
if ('serviceWorker' in navigator) {
  window.addEventListener('load', function() {
    navigator.serviceWorker.register('/sw.js')
      .then(function(registration) {
        console.log('[PWA] Service Worker registered successfully:', registration.scope);
        
        // Check for updates
        registration.addEventListener('updatefound', function() {
          const newWorker = registration.installing;
          console.log('[PWA] New service worker found');
          
          newWorker.addEventListener('statechange', function() {
            if (newWorker.state === 'installed') {
              if (navigator.serviceWorker.controller) {
                console.log('[PWA] New content is available; please refresh.');
                // Show update notification to user
                showUpdateNotification();
              } else {
                console.log('[PWA] Content is cached for offline use.');
              }
            }
          });
        });
      })
      .catch(function(error) {
        console.log('[PWA] Service Worker registration failed:', error);
      });
  });
}

// Show update notification
function showUpdateNotification() {
  // Create a simple notification for app update
  if ('Notification' in window && Notification.permission === 'granted') {
    new Notification('أشغال - تحديث متوفر', {
      body: 'نسخة جديدة من التطبيق متوفرة. يرجى إعادة تحميل الصفحة.',
      icon: '/icons/icon-192x192.svg',
      dir: 'rtl',
      lang: 'ar'
    });
  }
}

// Request notification permission
function requestNotificationPermission() {
  if ('Notification' in window && Notification.permission === 'default') {
    Notification.requestPermission().then(function(permission) {
      console.log('[PWA] Notification permission:', permission);
    });
  }
}

// Check PWA support
function checkPWASupport() {
  console.log('[PWA] Checking PWA support...');
  console.log('- Service Worker support:', 'serviceWorker' in navigator);
  console.log('- beforeinstallprompt support:', 'onbeforeinstallprompt' in window);
  console.log('- Is standalone mode:', window.matchMedia('(display-mode: standalone)').matches);
  console.log('- Is iOS:', /iPad|iPhone|iPod/.test(navigator.userAgent));
  console.log('- User Agent:', navigator.userAgent);
}

// Initialize PWA features
document.addEventListener('DOMContentLoaded', function() {
  checkPWASupport();
  // Request notification permission after user interaction
  document.body.addEventListener('click', function() {
    requestNotificationPermission();
  }, { once: true });
  
  // Add install prompt functionality
  let deferredPrompt;
  
  window.addEventListener('beforeinstallprompt', function(e) {
    console.log('[PWA] Install prompt available');
    e.preventDefault();
    deferredPrompt = e;
    
    // Show custom install button or banner
    showInstallPrompt();
  });
  
  window.addEventListener('appinstalled', function() {
    console.log('[PWA] App installed successfully');
    deferredPrompt = null;
  });
});

// Show install prompt
function showInstallPrompt() {
  console.log('[PWA] App can be installed');
  
  // Create a beautiful Arabic install prompt
  const installBanner = document.createElement('div');
  installBanner.id = 'pwa-install-banner';
  installBanner.innerHTML = `
    <div style="
      position: fixed;
      top: 0;
      left: 0;
      right: 0;
      background: linear-gradient(135deg, #3578E5 0%, #4F46E5 100%);
      color: white;
      padding: 16px 20px;
      display: flex;
      align-items: center;
      justify-content: space-between;
      font-family: 'Noto Sans Arabic', sans-serif;
      font-size: 14px;
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
      z-index: 10000;
      direction: rtl;
      text-align: right;
      backdrop-filter: blur(10px);
    ">
      <div style="display: flex; align-items: center; gap: 12px;">
        <i class="fas fa-mobile-alt" style="font-size: 20px;"></i>
        <div>
          <div style="font-weight: 600; margin-bottom: 2px;">تثبيت تطبيق أشغال</div>
          <div style="font-size: 12px; opacity: 0.9;">احصل على تجربة أفضل مع التطبيق</div>
        </div>
      </div>
      <div style="display: flex; gap: 8px;">
        <button id="pwa-install-btn" style="
          background: white;
          color: #3578E5;
          border: none;
          padding: 8px 16px;
          border-radius: 6px;
          font-family: 'Noto Sans Arabic', sans-serif;
          font-weight: 600;
          font-size: 13px;
          cursor: pointer;
          transition: all 0.2s ease;
        ">تثبيت</button>
        <button id="pwa-dismiss-btn" style="
          background: transparent;
          color: white;
          border: 1px solid rgba(255,255,255,0.3);
          padding: 8px 12px;
          border-radius: 6px;
          font-family: 'Noto Sans Arabic', sans-serif;
          font-size: 13px;
          cursor: pointer;
          transition: all 0.2s ease;
        ">لاحقاً</button>
      </div>
    </div>
  `;
  
  document.body.appendChild(installBanner);
  
  // Install button click
  document.getElementById('pwa-install-btn').addEventListener('click', function() {
    console.log('[PWA] Install button clicked, deferredPrompt:', deferredPrompt);
    
    if (deferredPrompt) {
      console.log('[PWA] Attempting to show install prompt...');
      deferredPrompt.prompt().then(function() {
        console.log('[PWA] Install prompt shown successfully');
      }).catch(function(error) {
        console.error('[PWA] Install prompt failed:', error);
        // Show manual instructions if auto prompt fails
        showManualInstall();
      });
      
      deferredPrompt.userChoice.then(function(choiceResult) {
        console.log('[PWA] Install choice:', choiceResult.outcome);
        if (choiceResult.outcome === 'accepted') {
          console.log('[PWA] User accepted install');
        } else {
          console.log('[PWA] User dismissed install');
        }
        installBanner.remove();
        deferredPrompt = null;
      }).catch(function(error) {
        console.error('[PWA] User choice error:', error);
        showManualInstall();
      });
    } else {
      console.log('[PWA] No deferredPrompt available, showing manual instructions');
      showManualInstall();
    }
  });
  
  // Function to show manual installation instructions
  function showManualInstall() {
    installBanner.remove();
    const manualInstructions = document.createElement('div');
    manualInstructions.innerHTML = `
        <div style="
          position: fixed;
          top: 50%;
          left: 50%;
          transform: translate(-50%, -50%);
          background: white;
          padding: 30px;
          border-radius: 15px;
          box-shadow: 0 20px 40px rgba(0,0,0,0.3);
          max-width: 350px;
          width: 90%;
          direction: rtl;
          text-align: right;
          font-family: 'Noto Sans Arabic', sans-serif;
          z-index: 20000;
          color: #333;
        ">
          <div style="text-align: center; margin-bottom: 20px;">
            <i class="fas fa-mobile-alt" style="font-size: 50px; color: #3578E5; margin-bottom: 15px;"></i>
            <h3 style="margin: 0; color: #3578E5; font-size: 18px;">تثبيت تطبيق أشغال</h3>
          </div>
          <div style="font-size: 14px; line-height: 1.6; margin-bottom: 20px;">
            <p><strong>🤖 أندرويد (Chrome):</strong><br/>
            القائمة (⋮) ← "إضافة إلى الشاشة الرئيسية"</p>
            
            <p><strong>🍎 آيفون (Safari):</strong><br/>
            زر المشاركة (📤) ← "Add to Home Screen"</p>
          </div>
          <button onclick="this.parentElement.parentElement.remove()" style="
            width: 100%;
            background: #3578E5;
            color: white;
            border: none;
            padding: 12px;
            border-radius: 8px;
            font-family: 'Noto Sans Arabic', sans-serif;
            font-size: 16px;
            cursor: pointer;
          ">فهمت</button>
        </div>
        <div style="
          position: fixed;
          top: 0;
          left: 0;
          right: 0;
          bottom: 0;
          background: rgba(0,0,0,0.5);
          z-index: 19999;
        " onclick="this.parentElement.remove()"></div>
      `;
      
      document.body.appendChild(manualInstructions);
  }
  
  // Dismiss button click
  document.getElementById('pwa-dismiss-btn').addEventListener('click', function() {
    installBanner.remove();
  });
  
  // Show banner after delay
  setTimeout(function() {
    installBanner.style.display = 'block';
  }, 2000);
}