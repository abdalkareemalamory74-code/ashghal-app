import { ref, uploadBytesResumable, getDownloadURL, deleteObject } from 'firebase/storage';
import { storage } from './firebase';

// Generate a unique filename with timestamp and random string
const generateUniqueFileName = (originalName: string): string => {
  const timestamp = Date.now();
  const randomString = Math.random().toString(36).substring(2, 15);
  const extension = originalName.split('.').pop()?.toLowerCase() || '';
  return `${timestamp}-${randomString}.${extension}`;
};

// Extract file path from Firebase Storage URL
const getStoragePathFromUrl = (url: string): string => {
  try {
    // Firebase Storage URLs have the format: 
    // https://firebasestorage.googleapis.com/v0/b/bucket/o/path%2Fto%2Ffile.jpg?token=...
    const urlObj = new URL(url);
    const pathname = urlObj.pathname;
    const encodedPath = pathname.split('/o/')[1]?.split('?')[0];
    return decodeURIComponent(encodedPath || '');
  } catch (error) {
    console.error('Error parsing storage URL:', error);
    throw new Error('Invalid storage URL');
  }
};

// Upload image to Firebase Storage
export const uploadImage = async (
  file: File,
  userId: string,
  postId: string = 'temp',
  onProgress?: (progress: number) => void
): Promise<string> => {
  try {
    // Validate file
    if (!file) {
      throw new Error('لم يتم توفير ملف');
    }

    // Check file size (5MB max)
    const maxSize = 5 * 1024 * 1024; // 5MB
    if (file.size > maxSize) {
      throw new Error('حجم الملف كبير جداً. الحد الأقصى 5MB');
    }

    // Check file type
    const allowedTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/webp'];
    if (!allowedTypes.includes(file.type)) {
      throw new Error('نوع الملف غير مدعوم. يُسمح بـ: JPG, PNG, WEBP');
    }

    // Generate unique filename
    const fileName = generateUniqueFileName(file.name);
    
    // Create storage reference
    const storageRef = ref(storage, `posts/${userId}/${postId}/${fileName}`);

    // Start upload with progress tracking
    const uploadTask = uploadBytesResumable(storageRef, file);

    return new Promise((resolve, reject) => {
      uploadTask.on(
        'state_changed',
        (snapshot) => {
          // Track upload progress
          const progress = (snapshot.bytesTransferred / snapshot.totalBytes) * 100;
          onProgress?.(progress);
        },
        (error) => {
          // Handle upload errors
          console.error('Upload error:', error);
          let errorMessage = 'فشل في رفع الصورة';
          
          switch (error.code) {
            case 'storage/unauthorized':
              errorMessage = 'غير مصرح لك برفع الصور';
              break;
            case 'storage/canceled':
              errorMessage = 'تم إلغاء رفع الصورة';
              break;
            case 'storage/quota-exceeded':
              errorMessage = 'تم تجاوز الحد المسموح للتخزين';
              break;
            case 'storage/invalid-format':
              errorMessage = 'تنسيق الملف غير صحيح';
              break;
            case 'storage/retry-limit-exceeded':
              errorMessage = 'تم تجاوز عدد المحاولات المسموحة';
              break;
          }
          
          reject(new Error(errorMessage));
        },
        async () => {
          try {
            // Upload completed successfully
            const downloadURL = await getDownloadURL(uploadTask.snapshot.ref);
            resolve(downloadURL);
          } catch (error) {
            console.error('Error getting download URL:', error);
            reject(new Error('فشل في الحصول على رابط الصورة'));
          }
        }
      );
    });

  } catch (error) {
    console.error('Error in uploadImage:', error);
    throw error instanceof Error ? error : new Error('فشل في رفع الصورة');
  }
};

// Delete image from Firebase Storage
export const deleteImage = async (imageUrl: string): Promise<void> => {
  try {
    if (!imageUrl) {
      throw new Error('لم يتم توفير رابط الصورة');
    }

    // Extract storage path from URL
    const storagePath = getStoragePathFromUrl(imageUrl);
    
    if (!storagePath) {
      throw new Error('مسار الصورة غير صحيح');
    }

    // Create storage reference
    const storageRef = ref(storage, storagePath);

    // Delete the file
    await deleteObject(storageRef);
    
  } catch (error) {
    console.error('Error deleting image:', error);
    
    // If file doesn't exist, don't throw error (it's already deleted)
    if (error instanceof Error && error.message.includes('object-not-found')) {
      return;
    }
    
    throw error instanceof Error ? error : new Error('فشل في حذف الصورة');
  }
};

// Upload multiple images
export const uploadMultipleImages = async (
  files: File[],
  userId: string,
  postId: string = 'temp',
  onProgress?: (fileIndex: number, progress: number) => void
): Promise<string[]> => {
  try {
    if (!files.length) {
      return [];
    }

    const uploadPromises = files.map(async (file, index) => {
      return uploadImage(
        file,
        userId,
        postId,
        (progress) => onProgress?.(index, progress)
      );
    });

    const uploadedUrls = await Promise.all(uploadPromises);
    return uploadedUrls;
    
  } catch (error) {
    console.error('Error uploading multiple images:', error);
    throw error instanceof Error ? error : new Error('فشل في رفع الصور');
  }
};

// Delete multiple images
export const deleteMultipleImages = async (imageUrls: string[]): Promise<void> => {
  try {
    if (!imageUrls.length) {
      return;
    }

    const deletePromises = imageUrls.map(url => deleteImage(url));
    await Promise.all(deletePromises);
    
  } catch (error) {
    console.error('Error deleting multiple images:', error);
    throw error instanceof Error ? error : new Error('فشل في حذف الصور');
  }
};

// Validate image file
export const validateImageFile = (file: File): { valid: boolean; error?: string } => {
  // Check file type
  const allowedTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/webp'];
  if (!allowedTypes.includes(file.type)) {
    return {
      valid: false,
      error: `نوع الملف غير مدعوم. الأنواع المدعومة: ${allowedTypes.join(', ')}`
    };
  }

  // Check file size (5MB max)
  const maxSize = 5 * 1024 * 1024; // 5MB
  if (file.size > maxSize) {
    return {
      valid: false,
      error: 'حجم الملف كبير جداً. الحد الأقصى 5MB'
    };
  }

  return { valid: true };
};

// Compress image before upload (optional utility)
export const compressImage = (
  file: File,
  maxWidth: number = 1920,
  maxHeight: number = 1080,
  quality: number = 0.8
): Promise<File> => {
  return new Promise((resolve) => {
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');
    const img = new Image();

    img.onload = () => {
      // Calculate new dimensions
      let { width, height } = img;
      
      if (width > height) {
        if (width > maxWidth) {
          height = (height * maxWidth) / width;
          width = maxWidth;
        }
      } else {
        if (height > maxHeight) {
          width = (width * maxHeight) / height;
          height = maxHeight;
        }
      }

      canvas.width = width;
      canvas.height = height;

      // Draw and compress
      ctx?.drawImage(img, 0, 0, width, height);
      
      canvas.toBlob(
        (blob) => {
          if (blob) {
            const compressedFile = new File([blob], file.name, {
              type: file.type,
              lastModified: Date.now()
            });
            resolve(compressedFile);
          } else {
            resolve(file); // Return original if compression fails
          }
        },
        file.type,
        quality
      );
    };

    img.src = URL.createObjectURL(file);
  });
};