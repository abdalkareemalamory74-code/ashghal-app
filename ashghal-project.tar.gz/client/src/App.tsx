import { Switch, Route } from "wouter";
import { QueryClientProvider } from "@tanstack/react-query";
import { queryClient } from "./lib/queryClient";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { AuthProvider } from "./context/AuthContext";
import { RequestsProvider } from "./context/RequestsContext";
import RoleGuard from "./components/Auth/RoleGuard";
import { BackButtonHandler } from "./hooks/useBackButton";

// Pages
import Home from "./pages/Home";
import Search from "./pages/Search";
import Category from "./pages/Category";
import SubCategory from "./pages/SubCategory";
import Login from "./pages/Login";
import Signup from "./pages/Signup";
import Dashboard from "./pages/Dashboard";
import CreateRequest from "./pages/CreateRequest";
import DemoCreateRequest from "./pages/DemoCreateRequest";
import MyRequests from "./pages/MyRequests";
import WorkerDashboard from "./pages/WorkerDashboard";
import AdminPanel from "./pages/AdminPanel";
import NotFound from "./pages/not-found";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/search" component={Search} />
      <Route path="/category/:category/:subcategory" component={SubCategory} />
      <Route path="/category/:category" component={Category} />
      <Route path="/login" component={Login} />
      <Route path="/signup" component={Signup} />
      <Route path="/demo-create-request" component={DemoCreateRequest} />
      
      <Route path="/dashboard">
        <RoleGuard allowedRoles={['user', 'worker', 'admin']}>
          <Dashboard />
        </RoleGuard>
      </Route>
      
      <Route path="/create-request">
        <RoleGuard allowedRoles={['user']}>
          <CreateRequest />
        </RoleGuard>
      </Route>
      
      <Route path="/my-requests">
        <RoleGuard allowedRoles={['user']}>
          <MyRequests />
        </RoleGuard>
      </Route>
      
      <Route path="/worker-dashboard">
        <RoleGuard allowedRoles={['worker']}>
          <WorkerDashboard />
        </RoleGuard>
      </Route>
      
      <Route path="/admin-panel">
        <RoleGuard allowedRoles={['admin']}>
          <AdminPanel />
        </RoleGuard>
      </Route>
      
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <RequestsProvider>
          <TooltipProvider>
            <BackButtonHandler />
            <Toaster />
            <Router />
          </TooltipProvider>
        </RequestsProvider>
      </AuthProvider>
    </QueryClientProvider>
  );
}

export default App;
