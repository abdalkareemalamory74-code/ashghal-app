import { createContext, useContext, useEffect, useState } from "react";
import { collection, query, where, onSnapshot, orderBy, doc, updateDoc, addDoc, serverTimestamp } from "firebase/firestore";
import { ref, uploadBytes, getDownloadURL } from "firebase/storage";
import { db, storage } from "../lib/firebase";
import { useAuth } from "./AuthContext";
import { useToast } from "@/hooks/use-toast";

export type RequestStatus = 'open' | 'accepted' | 'in_progress' | 'completed';
export type ServiceCategory = 'plumbing' | 'electrical' | 'ac' | 'painting' | 'cleaning' | 'carpentry' | 'other';

export interface ServiceRequest {
  id: string;
  title: string;
  description: string;
  category: ServiceCategory;
  address: string;
  photos: string[];
  status: RequestStatus;
  userId: string;
  userName: string;
  userPhone?: string;
  workerId?: string;
  workerName?: string;
  createdAt: Date;
  preferredDate?: string;
  preferredTime?: string;
  isEmergency: boolean;
}

export interface CreateRequestData {
  title: string;
  description: string;
  category: ServiceCategory;
  phone: string; // Added phone number field
  city: string; // Changed from address to city
  address?: string; // Made detailed address optional
  photos: File[];
  photoUrls?: string[]; // Add support for pre-uploaded image URLs
  preferredDate?: string;
  preferredTime?: string;
  isEmergency: boolean;
}

interface RequestsContextType {
  requests: ServiceRequest[];
  myRequests: ServiceRequest[];
  availableRequests: ServiceRequest[];
  loading: boolean;
  createRequest: (data: CreateRequestData) => Promise<void>;
  acceptRequest: (requestId: string) => Promise<void>;
  updateRequestStatus: (requestId: string, status: RequestStatus) => Promise<void>;
}

const RequestsContext = createContext<RequestsContextType | undefined>(undefined);

const useRequests = () => {
  const context = useContext(RequestsContext);
  if (context === undefined) {
    throw new Error('useRequests must be used within a RequestsProvider');
  }
  return context;
}

const RequestsProvider = ({ children }: { children: React.ReactNode }) => {
  const [requests, setRequests] = useState<ServiceRequest[]>([]);
  const [loading, setLoading] = useState(true);
  const { userProfile } = useAuth();
  const { toast } = useToast();

  useEffect(() => {
    if (!userProfile) {
      setRequests([]);
      setLoading(false);
      return;
    }

    let q;
    
    if (userProfile.role === 'admin') {
      // Admin can see all requests
      q = query(collection(db, 'requests'), orderBy('createdAt', 'desc'));
    } else if (userProfile.role === 'worker') {
      // Workers can see all requests or their own accepted requests
      q = query(collection(db, 'requests'), orderBy('createdAt', 'desc'));
    } else {
      // Users can see only their own requests
      q = query(
        collection(db, 'requests'),
        where('userId', '==', userProfile.uid),
        orderBy('createdAt', 'desc')
      );
    }

    const unsubscribe = onSnapshot(q, (snapshot: any) => {
      const requestsData: ServiceRequest[] = [];
      snapshot.forEach((doc: any) => {
        const data = doc.data();
        requestsData.push({
          id: doc.id,
          title: data.title,
          description: data.description,
          category: data.category,
          address: data.address,
          photos: data.photos || [],
          status: data.status,
          userId: data.userId,
          userName: data.userName,
          userPhone: data.userPhone,
          workerId: data.workerId,
          workerName: data.workerName,
          createdAt: data.createdAt?.toDate() || new Date(),
          preferredDate: data.preferredDate,
          preferredTime: data.preferredTime,
          isEmergency: data.isEmergency || false
        });
      });
      setRequests(requestsData);
      setLoading(false);
    }, (error: any) => {
      console.error('Error fetching requests:', error);
      toast({
        title: "خطأ",
        description: "حدث خطأ في تحميل الطلبات",
        variant: "destructive"
      });
      setLoading(false);
    });

    return () => unsubscribe();
  }, [userProfile, toast]);

  const createRequest = async (data: CreateRequestData) => {
    if (!userProfile) throw new Error('المستخدم غير مسجل الدخول');

    try {
      let finalPhotoUrls: string[] = [];

      // If pre-uploaded URLs are provided, use them
      if (data.photoUrls && data.photoUrls.length > 0) {
        finalPhotoUrls = data.photoUrls;
      } 
      // Otherwise, upload photos to Firebase Storage (legacy support)
      else if (data.photos && data.photos.length > 0) {
        for (const photo of data.photos) {
          const photoRef = ref(storage, `requests/${userProfile.uid}/${Date.now()}_${photo.name}`);
          const snapshot = await uploadBytes(photoRef, photo);
          const photoUrl = await getDownloadURL(snapshot.ref);
          finalPhotoUrls.push(photoUrl);
        }
      }

      // Create request document in Firestore
      await addDoc(collection(db, 'requests'), {
        title: data.title,
        description: data.description,
        category: data.category,
        city: data.city, // Use city field
        address: data.address || '', // Optional detailed address
        photos: finalPhotoUrls,
        status: 'open' as RequestStatus,
        userId: userProfile.uid,
        userName: userProfile.name,
        userPhone: data.phone, // Use phone from form data
        workerId: null,
        workerName: null,
        createdAt: serverTimestamp(),
        preferredDate: data.preferredDate || null,
        preferredTime: data.preferredTime || null,
        isEmergency: data.isEmergency
      });

      toast({
        title: "تم إنشاء الطلب",
        description: "تم إرسال طلبك بنجاح وسيتم التواصل معك قريباً"
      });
    } catch (error: any) {
      console.error('Error creating request:', error);
      toast({
        title: "خطأ في إنشاء الطلب",
        description: "حدث خطأ أثناء إرسال الطلب",
        variant: "destructive"
      });
      throw error;
    }
  };

  const acceptRequest = async (requestId: string) => {
    if (!userProfile || userProfile.role !== 'worker') {
      throw new Error('غير مصرح لك بقبول الطلبات');
    }

    try {
      await updateDoc(doc(db, 'requests', requestId), {
        status: 'accepted' as RequestStatus,
        workerId: userProfile.uid,
        workerName: userProfile.name
      });

      toast({
        title: "تم قبول الطلب",
        description: "تم قبول الطلب بنجاح وسيتم التواصل معك"
      });
    } catch (error: any) {
      console.error('Error accepting request:', error);
      toast({
        title: "خطأ في قبول الطلب",
        description: "حدث خطأ أثناء قبول الطلب",
        variant: "destructive"
      });
      throw error;
    }
  };

  const updateRequestStatus = async (requestId: string, status: RequestStatus) => {
    if (!userProfile) throw new Error('المستخدم غير مسجل الدخول');

    try {
      await updateDoc(doc(db, 'requests', requestId), {
        status
      });

      const statusMessages = {
        'open': 'تم تحديث الطلب إلى متاح',
        'accepted': 'تم قبول الطلب',
        'in_progress': 'بدء العمل في الطلب',
        'completed': 'تم إكمال الطلب'
      };

      toast({
        title: "تم تحديث الحالة",
        description: statusMessages[status]
      });
    } catch (error: any) {
      console.error('Error updating request status:', error);
      toast({
        title: "خطأ في تحديث الحالة",
        description: "حدث خطأ أثناء تحديث حالة الطلب",
        variant: "destructive"
      });
      throw error;
    }
  };

  // Derived data
  const myRequests = userProfile?.role === 'user' 
    ? requests.filter(req => req.userId === userProfile.uid)
    : [];

  const availableRequests = userProfile?.role === 'worker'
    ? requests.filter(req => req.status === 'open')
    : [];

  const value = {
    requests,
    myRequests,
    availableRequests,
    loading,
    createRequest,
    acceptRequest,
    updateRequestStatus
  };

  return <RequestsContext.Provider value={value}>{children}</RequestsContext.Provider>;
}

export { useRequests, RequestsProvider };
