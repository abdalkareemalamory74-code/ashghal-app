// الفئات الرئيسية
export const MAIN_CATEGORIES = {
  real_estate: 'عقارات',
  vehicles: 'مركبات',
  services: 'خدمات منوعة',
  products: 'منتجات للبيع',
  jobs: 'وظائف'
} as const;

// فئات العقارات
export const REAL_ESTATE_CATEGORIES = {
  apartments: 'شقق',
  houses: 'منازل',
  villas: 'فيلات',
  offices: 'مكاتب',
  shops: 'محلات تجارية',
  warehouses: 'مستودعات',
  lands: 'أراضي',
  farms: 'مزارع',
  other: 'أخرى'
} as const;

// أنواع عروض العقارات
export const REAL_ESTATE_TYPES = {
  for_sale: 'للبيع',
  for_rent: 'للإيجار'
} as const;

// فئات المركبات
export const VEHICLE_CATEGORIES = {
  cars: 'سيارات',
  motorcycles: 'دراجات نارية',
  trucks: 'شاحنات',
  buses: 'باصات',
  boats: 'قوارب',
  bicycles: 'دراجات هوائية',
  spare_parts: 'قطع غيار',
  accessories: 'إكسسوارات',
  other: 'أخرى'
} as const;

// فئات الخدمات
export const SERVICE_CATEGORIES = {
  electrical: 'كهرباء',
  plumbing: 'سباكة', 
  painting: 'دهان',
  construction: 'بناء',
  carpentry: 'نجارة',
  aluminum: 'ألمنيوم',
  ac_cooling: 'تبريد وتكييف',
  blacksmith: 'حدادة',
  well_drilling: 'حفر آبار',
  maintenance: 'صيانة منازل',
  transport: 'نقل وشحن',
  cleaning: 'تنظيف',
  gardening: 'بستنة',
  security: 'أمن وحراسة',
  catering: 'تموين وطعام',
  education: 'تعليم وتدريس',
  technology: 'تقنية ومعلوماتية',
  health: 'صحة وجمال',
  legal: 'خدمات قانونية',
  other: 'أخرى'
} as const;

// فئات المنتجات
export const PRODUCT_CATEGORIES = {
  electronics: 'أجهزة إلكترونية',
  appliances: 'أجهزة كهربائية',
  furniture: 'أثاث',
  clothing: 'ملابس',
  books: 'كتب',
  sports: 'رياضة ولياقة',
  toys: 'ألعاب',
  jewelry: 'مجوهرات',
  cosmetics: 'مستحضرات تجميل',
  food: 'طعام ومشروبات',
  tools: 'أدوات',
  art: 'تحف وفنون',
  medical: 'مستلزمات طبية',
  baby: 'مستلزمات أطفال',
  pets: 'مستلزمات حيوانات',
  garden: 'مستلزمات حديقة',
  other: 'أخرى'
} as const;

// فئات الوظائف
export const JOB_CATEGORIES = {
  engineering: 'هندسة',
  medicine: 'طب وصحة',
  education: 'تعليم وتدريس',
  technology: 'تقنية ومعلوماتية',
  finance: 'محاسبة ومالية',
  marketing: 'تسويق ومبيعات',
  management: 'إدارة',
  legal: 'قانون',
  arts: 'فنون وتصميم',
  media: 'إعلام وصحافة',
  hospitality: 'ضيافة وسياحة',
  construction: 'بناء وإنشاءات',
  transportation: 'نقل ومواصلات',
  retail: 'تجارة ومبيعات',
  manufacturing: 'صناعة وإنتاج',
  agriculture: 'زراعة',
  security: 'أمن وحراسة',
  cleaning: 'تنظيف وصيانة',
  food_service: 'خدمات طعام',
  other: 'أخرى'
} as const;

export const REQUEST_STATUSES = {
  open: 'متاح',
  accepted: 'مقبول',
  in_progress: 'قيد التنفيذ',
  completed: 'مكتمل'
} as const;

export const POST_TYPES = {
  service_offer: 'خدمة متوفرة',
  service_request: 'مطلوب خدمة', 
  job_offer: 'وظيفة متاحة',
  job_request: 'مطلوب وظيفة',
  real_estate_sale: 'عقار للبيع',
  real_estate_rent: 'عقار للإيجار',
  vehicle_sale: 'مركبة للبيع',
  product_sale: 'منتج للبيع'
} as const;

// نوع الإعلان الأساسي
export const AD_TYPES = {
  wanted: 'مطلوب',
  offered: 'معروض'
} as const;

export const USER_ROLES = {
  user: 'مستخدم',
  worker: 'مقاول', 
  admin: 'مدير'
} as const;

export const TIME_SLOTS = {
  morning: 'صباحاً (8-12)',
  afternoon: 'بعد الظهر (12-6)',
  evening: 'مساءً (6-10)',
  flexible: 'مرن'
} as const;

export const CITIES = {
  damascus: 'دمشق',
  aleppo: 'حلب',
  homs: 'حمص',
  hama: 'حماة',
  latakia: 'اللاذقية',
  tartus: 'طرطوس',
  deir_ezzor: 'دير الزور',
  raqqa: 'الرقة',
  hasaka: 'الحسكة',
  daraa: 'درعا',
  quneitra: 'القنيطرة',
  sweida: 'السويداء',
  idlib: 'إدلب',
  rif_damascus: 'ريف دمشق'
} as const;

export const MAX_FILE_SIZE = 10 * 1024 * 1024; // 10MB
export const SUPPORTED_IMAGE_TYPES = ['image/jpeg', 'image/jpg', 'image/png', 'image/webp'];
export const MAX_PHOTOS_PER_REQUEST = 5;

export const FIREBASE_COLLECTIONS = {
  USERS: 'users',
  REQUESTS: 'requests',
  RATINGS: 'ratings'
} as const;

export const STORAGE_PATHS = {
  REQUEST_PHOTOS: 'requests',
  PROFILE_PHOTOS: 'profiles'
} as const;

export const DEFAULT_PAGINATION_LIMIT = 20;

export const PHONE_REGEX = /^(09|9)(1|2|3|4|5|6|7|8|9)([0-9]{7})$/;
export const SYRIA_PHONE_PREFIX = '+963';

export const NOTIFICATION_TYPES = {
  REQUEST_CREATED: 'request_created',
  REQUEST_ACCEPTED: 'request_accepted',
  REQUEST_COMPLETED: 'request_completed',
  REQUEST_RATED: 'request_rated'
} as const;

export const ERROR_MESSAGES = {
  AUTH: {
    INVALID_CREDENTIALS: 'البريد الإلكتروني أو كلمة المرور غير صحيحة',
    EMAIL_ALREADY_IN_USE: 'البريد الإلكتروني مستخدم بالفعل',
    WEAK_PASSWORD: 'كلمة المرور ضعيفة',
    USER_NOT_FOUND: 'المستخدم غير موجود',
    NETWORK_ERROR: 'خطأ في الاتصال بالشبكة'
  },
  REQUEST: {
    CREATION_FAILED: 'فشل في إنشاء الطلب',
    UPDATE_FAILED: 'فشل في تحديث الطلب',
    DELETE_FAILED: 'فشل في حذف الطلب',
    NOT_FOUND: 'الطلب غير موجود',
    UNAUTHORIZED: 'غير مصرح لك بتنفيذ هذا الإجراء'
  },
  FILE: {
    TOO_LARGE: 'حجم الملف كبير جداً',
    INVALID_TYPE: 'نوع الملف غير مدعوم',
    UPLOAD_FAILED: 'فشل في رفع الملف'
  },
  GENERAL: {
    NETWORK_ERROR: 'خطأ في الاتصال',
    UNKNOWN_ERROR: 'حدث خطأ غير متوقع',
    VALIDATION_ERROR: 'خطأ في التحقق من البيانات'
  }
} as const;

export const SUCCESS_MESSAGES = {
  AUTH: {
    LOGIN_SUCCESS: 'تم تسجيل الدخول بنجاح',
    LOGOUT_SUCCESS: 'تم تسجيل الخروج بنجاح',
    SIGNUP_SUCCESS: 'تم إنشاء الحساب بنجاح'
  },
  REQUEST: {
    CREATED: 'تم إنشاء الطلب بنجاح',
    UPDATED: 'تم تحديث الطلب بنجاح',
    ACCEPTED: 'تم قبول الطلب بنجاح',
    COMPLETED: 'تم إكمال الطلب بنجاح',
    CANCELLED: 'تم إلغاء الطلب بنجاح'
  }
} as const;
