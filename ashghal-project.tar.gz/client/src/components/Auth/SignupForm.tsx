import { useState } from "react";
import { Link, useLocation } from "wouter";
import { useAuth, UserRole } from "../../context/AuthContext";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";

export default function SignupForm() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    password: "",
    confirmPassword: "",
    role: "" as UserRole,
    phone: ""
  });
  const [loading, setLoading] = useState(false);
  const { signup } = useAuth();
  const [, setLocation] = useLocation();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validate phone number format and requirement
    if (!formData.phone.trim()) {
      alert('رقم الهاتف مطلوب');
      return;
    }
    
    // Basic phone validation for Saudi Arabia format
    const phoneRegex = /^(05|009665)[0-9]{8}$/;
    if (!phoneRegex.test(formData.phone.trim())) {
      alert('رقم الهاتف غير صحيح. يجب أن يبدأ بـ 05 ويتكون من 10 أرقام');
      return;
    }
    
    if (formData.password !== formData.confirmPassword) {
      alert('كلمات المرور غير متطابقة');
      return;
    }
    
    if (formData.password.length < 6) {
      alert('كلمة المرور يجب أن تكون 6 أحرف على الأقل');
      return;
    }
    
    if (!formData.role) {
      alert('يجب اختيار نوع الحساب');
      return;
    }
    
    setLoading(true);

    try {
      // Email is optional, phone is required
      await signup(formData.email.trim() || undefined, formData.password, formData.name.trim(), formData.role, formData.phone.trim());
      setLocation("/dashboard");
    } catch (error) {
      // Error handling is done in AuthContext
    } finally {
      setLoading(false);
    }
  };

  const handleChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  return (
    <Card className="w-full max-w-md mx-auto" data-testid="signup-form">
      <CardHeader className="text-center">
        <CardTitle className="text-2xl font-bold">إنشاء حساب جديد</CardTitle>
        <CardDescription>
          أنشئ حسابك للبدء في استخدام أشغال
        </CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="name">الاسم الكامل</Label>
            <Input
              id="name"
              type="text"
              value={formData.name}
              onChange={(e) => handleChange("name", e.target.value)}
              placeholder="أدخل اسمك الكامل"
              required
              data-testid="input-name"
            />
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="email">البريد الإلكتروني <span className="text-sm text-muted-foreground">(اختياري)</span></Label>
            <Input
              id="email"
              type="email"
              value={formData.email}
              onChange={(e) => handleChange("email", e.target.value)}
              placeholder="أدخل بريدك الإلكتروني (اختياري)"
              data-testid="input-email"
            />
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="phone">رقم الهاتف <span className="text-red-500">*</span></Label>
            <Input
              id="phone"
              type="tel"
              value={formData.phone}
              onChange={(e) => handleChange("phone", e.target.value)}
              placeholder="05xxxxxxxx"
              required
              data-testid="input-phone"
            />
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="role">نوع الحساب</Label>
            <Select value={formData.role} onValueChange={(value) => handleChange("role", value)}>
              <SelectTrigger data-testid="select-role">
                <SelectValue placeholder="اختر نوع الحساب" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="user">مستخدم (طالب خدمة)</SelectItem>
                <SelectItem value="worker">مقاول (مقدم خدمة)</SelectItem>
              </SelectContent>
            </Select>
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="password">كلمة المرور</Label>
            <Input
              id="password"
              type="password"
              value={formData.password}
              onChange={(e) => handleChange("password", e.target.value)}
              placeholder="أدخل كلمة المرور"
              required
              data-testid="input-password"
            />
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="confirmPassword">تأكيد كلمة المرور</Label>
            <Input
              id="confirmPassword"
              type="password"
              value={formData.confirmPassword}
              onChange={(e) => handleChange("confirmPassword", e.target.value)}
              placeholder="أعد إدخال كلمة المرور"
              required
              data-testid="input-confirm-password"
            />
          </div>
          
          <Button 
            type="submit" 
            className="w-full" 
            disabled={loading || !formData.role || !formData.phone.trim()}
            data-testid="button-signup"
          >
            {loading ? "جاري إنشاء الحساب..." : "إنشاء حساب"}
          </Button>
        </form>
        
        <div className="mt-4 text-center">
          <p className="text-sm text-muted-foreground">
            لديك حساب بالفعل؟{" "}
            <Link href="/login">
              <a className="text-primary hover:underline" data-testid="link-login">
                تسجيل الدخول
              </a>
            </Link>
          </p>
        </div>
      </CardContent>
    </Card>
  );
}
