import { useState } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { useToast } from "@/hooks/use-toast";
import { CITIES, PHONE_REGEX, AD_TYPES, SERVICE_CATEGORIES, MAIN_CATEGORIES, REAL_ESTATE_CATEGORIES, VEHICLE_CATEGORIES, PRODUCT_CATEGORIES, JOB_CATEGORIES } from "../../utils/constants";

interface DemoFormData {
  title: string;
  description: string;
  adType: string; // مطلوب أم معروض
  mainCategory: string; // الفئة الرئيسية
  category: string;
  phone: string; // Added phone number field
  city: string; // Changed from address to city
  address: string; // Detailed address (optional)
  preferredDate: string;
  preferredTime: string;
  isEmergency: boolean;
}

export default function DemoRequestForm() {
  const [formData, setFormData] = useState<DemoFormData>({
    title: "",
    description: "",
    adType: "", // مطلوب أم معروض
    mainCategory: "", // الفئة الرئيسية
    category: "",
    phone: "", // Added phone number field
    city: "", // Changed from address to city
    address: "", // Optional detailed address
    preferredDate: "",
    preferredTime: "",
    isEmergency: false
  });
  const [loading, setLoading] = useState(false);
  const [, setLocation] = useLocation();
  const { toast } = useToast();

  const validatePhoneNumber = (phone: string) => {
    return PHONE_REGEX.test(phone);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validate phone number
    if (!validatePhoneNumber(formData.phone)) {
      toast({
        title: "خطأ في رقم الهاتف",
        description: "يرجى إدخال رقم هاتف سوري صحيح (مثال: 0932345678)",
        variant: "destructive",
      });
      return;
    }
    
    setLoading(true);

    // Simulate API call delay
    await new Promise(resolve => setTimeout(resolve, 1500));

    try {
      // Show success message for demo
      toast({
        title: "تم إرسال الطلب بنجاح! 🎉",
        description: "في النسخة الفعلية، سيتم حفظ طلبك وإشعار المقاولين المناسبين.",
        duration: 5000,
      });

      // Reset form
      setFormData({
        title: "",
        description: "",
        adType: "", // نوع الإعلان
        mainCategory: "", // الفئة الرئيسية
        category: "",
        phone: "", // Added phone field
        city: "", // Added city field
        address: "", // Optional detailed address
        preferredDate: "",
        preferredTime: "",
        isEmergency: false
      });

    } catch (error) {
      toast({
        title: "خطأ في الإرسال",
        description: "حدث خطأ أثناء إرسال الطلب. يرجى المحاولة مرة أخرى.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  // الحصول على الفئات الفرعية حسب الفئة الرئيسية
  const getSubCategories = (mainCategory: string) => {
    switch(mainCategory) {
      case 'real_estate': return REAL_ESTATE_CATEGORIES;
      case 'vehicles': return VEHICLE_CATEGORIES;
      case 'services': return SERVICE_CATEGORIES;
      case 'products': return PRODUCT_CATEGORIES;
      case 'jobs': return JOB_CATEGORIES;
      default: return {};
    }
  };
  
  const subCategories = formData.mainCategory ? getSubCategories(formData.mainCategory) : {};

  const timeSlots = [
    { value: 'morning', label: 'صباحاً (8-12)' },
    { value: 'afternoon', label: 'بعد الظهر (12-6)' },
    { value: 'evening', label: 'مساءً (6-10)' },
    { value: 'flexible', label: 'مرن' }
  ];

  return (
    <div className="w-full max-w-2xl mx-auto space-y-4">
      {/* Demo Notice */}
      <Alert className="border-blue-200 bg-blue-50">
        <div className="w-4 h-4 rounded-full bg-blue-500 flex items-center justify-center">
          <span className="text-white text-xs">ℹ</span>
        </div>
        <AlertDescription className="text-blue-800">
          <strong>نسخة تجريبية:</strong> هذا مثال على نموذج طلب الخدمة. البيانات لن يتم حفظها فعلياً.
          للاستخدام الفعلي، يرجى <a href="/signup" className="underline font-medium">إنشاء حساب</a> أو <a href="/login" className="underline font-medium">تسجيل الدخول</a>.
        </AlertDescription>
      </Alert>

      <Card data-testid="demo-request-form">
        <CardHeader>
          <CardTitle className="text-xl font-semibold">طلب خدمة جديد - تجريبي</CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-6">
            {/* نوع الإعلان - مطلوب أم معروض */}
            <div className="space-y-2">
              <Label htmlFor="adType">نوع الإعلان</Label>
              <Select 
                value={formData.adType} 
                onValueChange={(value) => setFormData(prev => ({ ...prev, adType: value, mainCategory: "", category: "" }))}
              >
                <SelectTrigger data-testid="select-ad-type">
                  <SelectValue placeholder="اختر نوع الإعلان" />
                </SelectTrigger>
                <SelectContent>
                  {Object.entries(AD_TYPES).map(([key, value]) => (
                    <SelectItem key={key} value={key}>
                      {value}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* الفئة الرئيسية */}
            {formData.adType && (
              <div className="space-y-2">
                <Label htmlFor="mainCategory">الفئة الرئيسية</Label>
                <Select 
                  value={formData.mainCategory} 
                  onValueChange={(value) => setFormData(prev => ({ ...prev, mainCategory: value, category: "" }))}
                >
                  <SelectTrigger data-testid="select-main-category">
                    <SelectValue placeholder="اختر الفئة الرئيسية" />
                  </SelectTrigger>
                  <SelectContent>
                    {Object.entries(MAIN_CATEGORIES).map(([key, value]) => (
                      <SelectItem key={key} value={key}>
                        {value}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            )}

            {/* الفئة الفرعية */}
            {formData.mainCategory && Object.keys(subCategories).length > 0 && (
              <div className="space-y-2">
                <Label htmlFor="category">الفئة الفرعية</Label>
                <Select 
                  value={formData.category} 
                  onValueChange={(value) => setFormData(prev => ({ ...prev, category: value }))}
                >
                  <SelectTrigger data-testid="select-category">
                    <SelectValue placeholder="اختر الفئة الفرعية" />
                  </SelectTrigger>
                  <SelectContent>
                    {Object.entries(subCategories).map(([key, value]) => (
                      <SelectItem key={key} value={key}>
                        {String(value)}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            )}

            {/* Request Title */}
            <div className="space-y-2">
              <Label htmlFor="title">عنوان الطلب</Label>
              <Input
                id="title"
                value={formData.title}
                onChange={(e) => setFormData(prev => ({ ...prev, title: e.target.value }))}
                placeholder="مثال: إصلاح تسريب في الحمام"
                required
                data-testid="input-title"
              />
            </div>

            {/* Description */}
            <div className="space-y-2">
              <Label htmlFor="description">وصف المشكلة</Label>
              <Textarea
                id="description"
                rows={4}
                value={formData.description}
                onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
                placeholder="اشرح المشكلة بالتفصيل..."
                required
                data-testid="textarea-description"
              />
            </div>

            {/* Phone Number */}
            <div className="space-y-2">
              <Label htmlFor="phone">رقم الهاتف للتواصل</Label>
              <Input
                id="phone"
                value={formData.phone}
                onChange={(e) => setFormData(prev => ({ ...prev, phone: e.target.value }))}
                placeholder="مثال: 0932345678"
                required
                data-testid="input-phone"
              />
            </div>

            {/* City Selection */}
            <div className="space-y-2">
              <Label htmlFor="city">المحافظة</Label>
              <Select 
                value={formData.city} 
                onValueChange={(value) => setFormData(prev => ({ ...prev, city: value }))}
              >
                <SelectTrigger data-testid="select-city">
                  <SelectValue placeholder="اختر المحافظة" />
                </SelectTrigger>
                <SelectContent>
                  {Object.entries(CITIES).map(([key, value]) => (
                    <SelectItem key={key} value={key}>
                      {value}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Detailed Address */}
            <div className="space-y-2">
              <Label htmlFor="address">العنوان التفصيلي (اختياري)</Label>
              <Input
                id="address"
                value={formData.address}
                onChange={(e) => setFormData(prev => ({ ...prev, address: e.target.value }))}
                placeholder="مثال: حي النصر، شارع الملك فهد، مبنى رقم 15"
                data-testid="input-address"
              />
            </div>

            {/* Photo Upload - Disabled in Demo */}
            <div className="space-y-2">
              <Label>صور المشكلة (اختياري)</Label>
              <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center bg-gray-50">
                <div className="w-12 h-12 mx-auto mb-3 text-gray-400">
                  📷
                </div>
                <p className="text-sm text-gray-500 mb-2">
                  رفع الصور متاح في النسخة الكاملة فقط
                </p>
                <p className="text-xs text-gray-400">
                  سجل دخولك لرفع الصور
                </p>
              </div>
            </div>

            {/* Preferred Time */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="preferredDate">التاريخ المفضل</Label>
                <Input
                  id="preferredDate"
                  type="date"
                  value={formData.preferredDate}
                  onChange={(e) => setFormData(prev => ({ ...prev, preferredDate: e.target.value }))}
                  data-testid="input-preferred-date"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="preferredTime">الوقت المفضل</Label>
                <Select 
                  value={formData.preferredTime} 
                  onValueChange={(value) => setFormData(prev => ({ ...prev, preferredTime: value }))}
                >
                  <SelectTrigger data-testid="select-preferred-time">
                    <SelectValue placeholder="اختر الوقت" />
                  </SelectTrigger>
                  <SelectContent>
                    {timeSlots.map(slot => (
                      <SelectItem key={slot.value} value={slot.value}>
                        {slot.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            {/* Emergency */}
            <div className="flex items-center space-x-3 space-x-reverse">
              <Checkbox
                id="emergency"
                checked={formData.isEmergency}
                onCheckedChange={(checked) => setFormData(prev => ({ ...prev, isEmergency: checked as boolean }))}
                data-testid="checkbox-emergency"
              />
              <Label htmlFor="emergency" className="text-sm font-medium">
                طلب عاجل (رسوم إضافية)
              </Label>
            </div>

            {/* Submit Button */}
            <div className="flex justify-end space-x-3 space-x-reverse pt-4">
              <Button 
                type="button" 
                variant="secondary"
                onClick={() => setLocation("/")}
                data-testid="button-cancel"
              >
                إلغاء
              </Button>
              <Button 
                type="submit" 
                disabled={loading || !formData.adType || !formData.mainCategory || !formData.category || !formData.phone || !formData.city}
                data-testid="button-submit"
              >
                {loading ? "جاري الإرسال..." : "إرسال الطلب (تجريبي)"}
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}