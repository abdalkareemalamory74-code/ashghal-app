import { ServiceRequest, useRequests } from "../../context/RequestsContext";
import { useAuth } from "../../context/AuthContext";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useState } from "react";

interface RequestDetailModalProps {
  request: ServiceRequest | null;
  isOpen: boolean;
  onClose: () => void;
}

export default function RequestDetailModal({ request, isOpen, onClose }: RequestDetailModalProps) {
  const { userProfile } = useAuth();
  const { updateRequestStatus } = useRequests();
  const [selectedStatus, setSelectedStatus] = useState<string>("");
  const [updating, setUpdating] = useState(false);

  if (!request) return null;

  const getStatusBadge = (status: string) => {
    const statusConfig = {
      'open': { className: 'status-open', text: 'متاح' },
      'accepted': { className: 'status-accepted', text: 'مقبول' },
      'in_progress': { className: 'status-in_progress', text: 'قيد التنفيذ' },
      'completed': { className: 'status-completed', text: 'مكتمل' }
    };
    
    const config = statusConfig[status as keyof typeof statusConfig] || statusConfig.open;
    return <Badge className={config.className}>{config.text}</Badge>;
  };

  const getCategoryText = (category: string) => {
    const categories = {
      'plumbing': 'سباكة',
      'electrical': 'كهرباء',
      'ac': 'تكييف',
      'painting': 'دهان',
      'cleaning': 'تنظيف',
      'carpentry': 'نجارة',
      'other': 'أخرى'
    };
    return categories[category as keyof typeof categories] || category;
  };

  const formatDate = (date: Date) => {
    return new Intl.DateTimeFormat('ar-SA', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: 'numeric',
      minute: '2-digit'
    }).format(date);
  };

  const handleStatusUpdate = async () => {
    if (!selectedStatus) return;
    
    setUpdating(true);
    try {
      await updateRequestStatus(request.id, selectedStatus as any);
      onClose();
    } catch (error) {
      // Error handling is done in RequestsContext
    } finally {
      setUpdating(false);
    }
  };

  const canUpdateStatus = () => {
    if (userProfile?.role === 'admin') return true;
    if (userProfile?.role === 'worker' && request.workerId === userProfile.uid) return true;
    if (userProfile?.role === 'user' && request.userId === userProfile.uid && request.status === 'completed') return true;
    return false;
  };

  const getAvailableStatuses = () => {
    const allStatuses = [
      { value: 'open', label: 'متاح' },
      { value: 'accepted', label: 'مقبول' },
      { value: 'in_progress', label: 'قيد التنفيذ' },
      { value: 'completed', label: 'مكتمل' }
    ];

    if (userProfile?.role === 'admin') return allStatuses;
    
    if (userProfile?.role === 'worker') {
      return allStatuses.filter(s => s.value !== 'open');
    }
    
    return allStatuses.filter(s => s.value === 'completed');
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-screen overflow-y-auto" data-testid="request-detail-modal">
        <DialogHeader>
          <DialogTitle data-testid="modal-title">{request.title}</DialogTitle>
        </DialogHeader>
        
        <div className="space-y-6">
          {/* Status and Category */}
          <div className="flex items-center space-x-4 space-x-reverse">
            {getStatusBadge(request.status)}
            <Badge variant="secondary">{getCategoryText(request.category)}</Badge>
            {request.isEmergency && (
              <Badge className="bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200">
                عاجل
              </Badge>
            )}
          </div>
          
          {/* Description */}
          <div>
            <h4 className="font-medium mb-2">وصف المشكلة</h4>
            <p className="text-muted-foreground" data-testid="request-description">
              {request.description}
            </p>
          </div>
          
          {/* Address and Time */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <h4 className="font-medium mb-2">العنوان</h4>
              <p className="text-muted-foreground" data-testid="request-address">
                {request.address}
              </p>
            </div>
            <div>
              <h4 className="font-medium mb-2">تاريخ الإنشاء</h4>
              <p className="text-muted-foreground" data-testid="request-created-at">
                {formatDate(request.createdAt)}
              </p>
            </div>
          </div>

          {/* Preferred Time */}
          {(request.preferredDate || request.preferredTime) && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {request.preferredDate && (
                <div>
                  <h4 className="font-medium mb-2">التاريخ المفضل</h4>
                  <p className="text-muted-foreground">{request.preferredDate}</p>
                </div>
              )}
              {request.preferredTime && (
                <div>
                  <h4 className="font-medium mb-2">الوقت المفضل</h4>
                  <p className="text-muted-foreground">{request.preferredTime}</p>
                </div>
              )}
            </div>
          )}
          
          {/* Photos */}
          {request.photos.length > 0 && (
            <div>
              <h4 className="font-medium mb-3">صور المشكلة</h4>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-4" data-testid="request-photos">
                {request.photos.map((photo, index) => (
                  <img
                    key={index}
                    src={photo}
                    alt={`صورة ${index + 1}`}
                    className="w-full h-32 object-cover rounded-lg border border-border cursor-pointer hover:opacity-75 transition-opacity"
                    onClick={() => window.open(photo, '_blank')}
                    data-testid={`img-photo-${index}`}
                  />
                ))}
              </div>
            </div>
          )}
          
          {/* Customer Info */}
          <div>
            <h4 className="font-medium mb-3">معلومات العميل</h4>
            <div className="flex items-center space-x-4 space-x-reverse p-4 bg-muted rounded-lg">
              <div className="w-12 h-12 bg-secondary rounded-full flex items-center justify-center">
                <i className="fas fa-user text-secondary-foreground"></i>
              </div>
              <div className="flex-1">
                <p className="font-medium" data-testid="customer-name">{request.userName}</p>
                {request.userPhone && (
                  <p className="text-sm text-muted-foreground" data-testid="customer-phone">
                    {request.userPhone}
                  </p>
                )}
              </div>
              {request.userPhone && (
                <Button size="sm" data-testid="button-contact-customer">
                  <i className="fas fa-phone ml-2"></i>
                  اتصل
                </Button>
              )}
            </div>
          </div>
          
          {/* Worker Info (if assigned) */}
          {request.workerId && (
            <div>
              <h4 className="font-medium mb-3">معلومات المقاول</h4>
              <div className="flex items-center space-x-4 space-x-reverse p-4 bg-muted rounded-lg">
                <div className="w-12 h-12 bg-primary rounded-full flex items-center justify-center">
                  <i className="fas fa-hard-hat text-primary-foreground"></i>
                </div>
                <div className="flex-1">
                  <p className="font-medium" data-testid="worker-name">
                    {request.workerName || 'مقاول'}
                  </p>
                  <p className="text-sm text-muted-foreground">
                    فني {getCategoryText(request.category)}
                  </p>
                </div>
                <Button size="sm" data-testid="button-contact-worker">
                  <i className="fas fa-phone ml-2"></i>
                  اتصل
                </Button>
              </div>
            </div>
          )}
          
          {/* Status Update */}
          {canUpdateStatus() && (
            <div className="border-t border-border pt-4">
              <h4 className="font-medium mb-3">تحديث الحالة</h4>
              <div className="flex items-center space-x-3 space-x-reverse">
                <Select value={selectedStatus} onValueChange={setSelectedStatus}>
                  <SelectTrigger className="w-48" data-testid="select-status">
                    <SelectValue placeholder="اختر الحالة الجديدة" />
                  </SelectTrigger>
                  <SelectContent>
                    {getAvailableStatuses().map(status => (
                      <SelectItem key={status.value} value={status.value}>
                        {status.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <Button 
                  onClick={handleStatusUpdate}
                  disabled={!selectedStatus || updating}
                  data-testid="button-update-status"
                >
                  {updating ? "جاري التحديث..." : "تحديث"}
                </Button>
              </div>
            </div>
          )}
          
          {/* Actions */}
          <div className="flex justify-end space-x-3 space-x-reverse pt-4 border-t border-border">
            <Button variant="secondary" onClick={onClose} data-testid="button-close">
              إغلاق
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
