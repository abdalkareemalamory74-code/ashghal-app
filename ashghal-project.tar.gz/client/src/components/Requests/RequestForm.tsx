import { useState } from "react";
import { useLocation } from "wouter";
import { useRequests, CreateRequestData, ServiceCategory } from "../../context/RequestsContext";
import { useAuth } from "../../context/AuthContext";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ImageUpload } from "@/components/ui/image-upload";
import { CITIES, PHONE_REGEX, AD_TYPES, MAIN_CATEGORIES, SERVICE_CATEGORIES, REAL_ESTATE_CATEGORIES, VEHICLE_CATEGORIES, PRODUCT_CATEGORIES, JOB_CATEGORIES } from "../../utils/constants";

export default function RequestForm() {
  // Get URL parameters
  const searchParams = new URLSearchParams(window.location.search);
  const initialAdType = searchParams.get('adType') || '';
  const initialMainCategory = searchParams.get('mainCategory') || '';
  
  const [formData, setFormData] = useState<CreateRequestData>({
    title: "",
    description: "",
    category: "" as ServiceCategory,
    phone: "", // Added phone number field
    city: "", // Changed from address to city
    address: "", // Optional detailed address
    photos: [],
    preferredDate: "",
    preferredTime: "",
    isEmergency: false
  });
  
  // Additional state for the new form structure
  const [adType, setAdType] = useState(initialAdType);
  const [mainCategory, setMainCategory] = useState(initialMainCategory);
  const [loading, setLoading] = useState(false);
  const [imageUrls, setImageUrls] = useState<string[]>([]);
  const { createRequest } = useRequests();
  const { userProfile } = useAuth();
  const [, setLocation] = useLocation();

  const validatePhoneNumber = (phone: string) => {
    return PHONE_REGEX.test(phone);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validate phone number
    if (!validatePhoneNumber(formData.phone)) {
      alert("يرجى إدخال رقم هاتف سوري صحيح (مثال: 0932345678)");
      return;
    }
    
    setLoading(true);

    try {
      // Create request data with pre-uploaded image URLs
      const requestData: CreateRequestData = {
        ...formData,
        photos: [], // No file objects needed
        photoUrls: imageUrls // Pass the uploaded URLs
      };

      await createRequest(requestData);
      setLocation("/my-requests");
    } catch (error) {
      // Error handling is done in RequestsContext
    } finally {
      setLoading(false);
    }
  };

  // الحصول على الفئات الفرعية حسب الفئة الرئيسية
  const getSubCategories = (mainCat: string) => {
    switch(mainCat) {
      case 'real_estate': return REAL_ESTATE_CATEGORIES;
      case 'vehicles': return VEHICLE_CATEGORIES;
      case 'services': return SERVICE_CATEGORIES;
      case 'products': return PRODUCT_CATEGORIES;
      case 'jobs': return JOB_CATEGORIES;
      default: return {};
    }
  };
  
  const subCategories = mainCategory ? getSubCategories(mainCategory) : {};

  const timeSlots = [
    { value: 'morning', label: 'صباحاً (8-12)' },
    { value: 'afternoon', label: 'بعد الظهر (12-6)' },
    { value: 'evening', label: 'مساءً (6-10)' },
    { value: 'flexible', label: 'مرن' }
  ];

  return (
    <Card className="w-full max-w-2xl mx-auto" data-testid="request-form">
      <CardHeader>
        <CardTitle className="text-xl font-semibold">طلب خدمة جديد</CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-6">
          {/* نوع الإعلان - مطلوب أم معروض */}
          <div className="space-y-2">
            <Label htmlFor="adType">نوع الإعلان</Label>
            <Select 
              value={adType} 
              onValueChange={(value) => {
                setAdType(value);
                setMainCategory('');
                setFormData(prev => ({ ...prev, category: '' as ServiceCategory }));
              }}
            >
              <SelectTrigger data-testid="select-ad-type">
                <SelectValue placeholder="اختر نوع الإعلان" />
              </SelectTrigger>
              <SelectContent>
                {Object.entries(AD_TYPES).map(([key, value]) => (
                  <SelectItem key={key} value={key}>
                    {value}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* الفئة الرئيسية */}
          {adType && (
            <div className="space-y-2">
              <Label htmlFor="mainCategory">الفئة الرئيسية</Label>
              <Select 
                value={mainCategory} 
                onValueChange={(value) => {
                  setMainCategory(value);
                  setFormData(prev => ({ ...prev, category: '' as ServiceCategory }));
                }}
              >
                <SelectTrigger data-testid="select-main-category">
                  <SelectValue placeholder="اختر الفئة الرئيسية" />
                </SelectTrigger>
                <SelectContent>
                  {Object.entries(MAIN_CATEGORIES).map(([key, value]) => (
                    <SelectItem key={key} value={key}>
                      {value}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          )}

          {/* الفئة الفرعية */}
          {mainCategory && Object.keys(subCategories).length > 0 && (
            <div className="space-y-2">
              <Label htmlFor="category">الفئة الفرعية</Label>
              <Select 
                value={formData.category} 
                onValueChange={(value) => setFormData(prev => ({ ...prev, category: value as ServiceCategory }))}
              >
                <SelectTrigger data-testid="select-category">
                  <SelectValue placeholder="اختر الفئة الفرعية" />
                </SelectTrigger>
                <SelectContent>
                  {Object.entries(subCategories).map(([key, value]) => (
                    <SelectItem key={key} value={key}>
                      {String(value)}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          )}

          {/* Request Title */}
          <div className="space-y-2">
            <Label htmlFor="title">عنوان الطلب</Label>
            <Input
              id="title"
              value={formData.title}
              onChange={(e) => setFormData(prev => ({ ...prev, title: e.target.value }))}
              placeholder="مثال: إصلاح تسريب في الحمام"
              required
              data-testid="input-title"
            />
          </div>

          {/* Description */}
          <div className="space-y-2">
            <Label htmlFor="description">وصف المشكلة</Label>
            <Textarea
              id="description"
              rows={4}
              value={formData.description}
              onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
              placeholder="اشرح المشكلة بالتفصيل..."
              required
              data-testid="textarea-description"
            />
          </div>

          {/* Phone Number */}
          <div className="space-y-2">
            <Label htmlFor="phone">رقم الهاتف للتواصل</Label>
            <Input
              id="phone"
              value={formData.phone}
              onChange={(e) => setFormData(prev => ({ ...prev, phone: e.target.value }))}
              placeholder="مثال: 0932345678"
              required
              data-testid="input-phone"
            />
          </div>

          {/* City Selection */}
          <div className="space-y-2">
            <Label htmlFor="city">المحافظة</Label>
            <Select 
              value={formData.city} 
              onValueChange={(value) => setFormData(prev => ({ ...prev, city: value }))}
            >
              <SelectTrigger data-testid="select-city">
                <SelectValue placeholder="اختر المحافظة" />
              </SelectTrigger>
              <SelectContent>
                {Object.entries(CITIES).map(([key, value]) => (
                  <SelectItem key={key} value={key}>
                    {value}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Detailed Address */}
          <div className="space-y-2">
            <Label htmlFor="address">العنوان التفصيلي (اختياري)</Label>
            <Input
              id="address"
              value={formData.address}
              onChange={(e) => setFormData(prev => ({ ...prev, address: e.target.value }))}
              placeholder="مثال: حي النصر، شارع الملك فهد، مبنى رقم 15"
              data-testid="input-address"
            />
          </div>

          {/* Photo Upload */}
          <div className="space-y-2">
            <Label>صور المشكلة (اختياري)</Label>
            {userProfile && (
              <ImageUpload
                value={imageUrls}
                onChange={setImageUrls}
                maxImages={5}
                maxSize={5}
                userId={userProfile.uid}
                postId="request"
                disabled={loading}
              />
            )}
          </div>

          {/* Preferred Time */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="preferredDate">التاريخ المفضل</Label>
              <Input
                id="preferredDate"
                type="date"
                value={formData.preferredDate}
                onChange={(e) => setFormData(prev => ({ ...prev, preferredDate: e.target.value }))}
                data-testid="input-preferred-date"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="preferredTime">الوقت المفضل</Label>
              <Select 
                value={formData.preferredTime} 
                onValueChange={(value) => setFormData(prev => ({ ...prev, preferredTime: value }))}
              >
                <SelectTrigger data-testid="select-preferred-time">
                  <SelectValue placeholder="اختر الوقت" />
                </SelectTrigger>
                <SelectContent>
                  {timeSlots.map(slot => (
                    <SelectItem key={slot.value} value={slot.value}>
                      {slot.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Emergency */}
          <div className="flex items-center space-x-3 space-x-reverse">
            <Checkbox
              id="emergency"
              checked={formData.isEmergency}
              onCheckedChange={(checked) => setFormData(prev => ({ ...prev, isEmergency: checked as boolean }))}
              data-testid="checkbox-emergency"
            />
            <Label htmlFor="emergency" className="text-sm font-medium">
              طلب عاجل (رسوم إضافية)
            </Label>
          </div>

          {/* Submit Button */}
          <div className="flex justify-end space-x-3 space-x-reverse pt-4">
            <Button 
              type="button" 
              variant="secondary"
              onClick={() => setLocation("/dashboard")}
              data-testid="button-cancel"
            >
              إلغاء
            </Button>
            <Button 
              type="submit" 
              disabled={loading || !adType || !mainCategory || !formData.category || !formData.phone || !formData.city || !userProfile}
              data-testid="button-submit"
            >
              {loading ? "جاري الإرسال..." : "إرسال الطلب"}
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
}
