import { ServiceRequest } from "../../context/RequestsContext";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useAuth } from "../../context/AuthContext";

interface RequestCardProps {
  request: ServiceRequest;
  onViewDetails?: (request: ServiceRequest) => void;
  onAccept?: (requestId: string) => void;
}

export default function RequestCard({ request, onViewDetails, onAccept }: RequestCardProps) {
  const { userProfile } = useAuth();

  const getStatusBadge = (status: string) => {
    const statusConfig = {
      'open': { className: 'status-open', text: 'متاح' },
      'accepted': { className: 'status-accepted', text: 'مقبول' },
      'in_progress': { className: 'status-in_progress', text: 'قيد التنفيذ' },
      'completed': { className: 'status-completed', text: 'مكتمل' }
    };
    
    const config = statusConfig[status as keyof typeof statusConfig] || statusConfig.open;
    return <Badge className={config.className}>{config.text}</Badge>;
  };

  const getCategoryText = (category: string) => {
    const categories = {
      'plumbing': 'سباكة',
      'electrical': 'كهرباء',
      'ac': 'تكييف',
      'painting': 'دهان',
      'cleaning': 'تنظيف',
      'carpentry': 'نجارة',
      'other': 'أخرى'
    };
    return categories[category as keyof typeof categories] || category;
  };

  const formatDate = (date: Date) => {
    return new Intl.DateTimeFormat('ar-SA', {
      month: 'long',
      day: 'numeric',
      hour: 'numeric',
      minute: '2-digit'
    }).format(date);
  };

  return (
    <div 
      className="border border-border rounded-lg p-4 hover:shadow-md transition-shadow bg-card card-fixed"
      data-testid={`card-request-${request.id}`}
    >
      <div className="flex items-start justify-between mb-3">
        <div className="flex-1">
          <div className="flex items-center space-x-3 space-x-reverse mb-2">
            <h4 className="card-title arabic-text" data-testid={`text-title-${request.id}`}>
              {request.title}
            </h4>
            {getStatusBadge(request.status)}
            {request.isEmergency && (
              <Badge className="bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200">
                عاجل
              </Badge>
            )}
          </div>
          <p className="card-description-short arabic-text mb-3" data-testid={`text-description-${request.id}`}>
            {request.description}
          </p>
          <div className="flex items-center space-x-4 space-x-reverse text-xs text-muted-foreground">
            <span data-testid={`text-category-${request.id}`}>
              <i className="fas fa-tools ml-1"></i>
              {getCategoryText(request.category)}
            </span>
            <span data-testid={`text-date-${request.id}`}>
              <i className="fas fa-clock ml-1"></i>
              {formatDate(request.createdAt)}
            </span>
            <span data-testid={`text-address-${request.id}`}>
              <i className="fas fa-map-marker-alt ml-1"></i>
              {request.address}
            </span>
          </div>
        </div>
      </div>

      {/* Photos preview */}
      {request.photos.length > 0 && (
        <div className="flex items-center space-x-4 space-x-reverse mb-4">
          <div className="flex -space-x-2 space-x-reverse">
            {request.photos.slice(0, 2).map((photo, index) => (
              <img
                key={index}
                src={photo}
                alt={`صورة ${index + 1}`}
                className="w-12 h-12 rounded border-2 border-card object-cover"
                data-testid={`img-photo-${request.id}-${index}`}
              />
            ))}
            {request.photos.length > 2 && (
              <div className="w-12 h-12 rounded border-2 border-card bg-muted flex items-center justify-center text-xs">
                +{request.photos.length - 2}
              </div>
            )}
          </div>
          <p className="text-xs text-muted-foreground">
            {request.photos.length} صور
          </p>
        </div>
      )}

      {/* Customer/Worker Info */}
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-3 space-x-reverse">
          <div className="w-8 h-8 bg-muted rounded-full flex items-center justify-center">
            <i className="fas fa-user text-muted-foreground text-sm"></i>
          </div>
          <div>
            <p className="text-sm font-medium" data-testid={`text-user-${request.id}`}>
              {userProfile?.role === 'worker' ? request.userName : 
               request.workerName || 'لم يتم التعيين بعد'}
            </p>
            {userProfile?.role === 'worker' && request.userPhone && (
              <p className="text-xs text-muted-foreground">
                {request.userPhone}
              </p>
            )}
          </div>
        </div>

        <div className="flex items-center space-x-2 space-x-reverse">
          <Button
            variant="secondary"
            size="sm"
            onClick={() => onViewDetails?.(request)}
            data-testid={`button-details-${request.id}`}
          >
            التفاصيل
          </Button>
          
          {userProfile?.role === 'worker' && request.status === 'open' && (
            <Button
              size="sm"
              onClick={() => onAccept?.(request.id)}
              data-testid={`button-accept-${request.id}`}
            >
              قبول الطلب
            </Button>
          )}
        </div>
      </div>
    </div>
  );
}
