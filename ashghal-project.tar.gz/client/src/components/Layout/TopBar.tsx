import { Button } from "@/components/ui/button";

interface TopBarProps {
  onMenuClick: () => void;
}

export default function TopBar({ onMenuClick }: TopBarProps) {
  return (
    <header className="bg-card border-b border-border mobile-padding flex items-center justify-between prevent-overflow" data-testid="topbar">
      <div className="flex items-center space-x-4 space-x-reverse">
        <Button
          variant="ghost"
          size="sm"
          className="lg:hidden p-2"
          onClick={onMenuClick}
          data-testid="button-menu-toggle"
        >
          <i className="fas fa-bars"></i>
        </Button>
        <h2 className="mobile-text md:text-lg font-semibold" data-testid="page-title">
          أشغال
        </h2>
      </div>
      
      <div className="flex items-center space-x-4 space-x-reverse">
        {/* Notifications */}
        <Button variant="ghost" size="sm" className="relative p-2" data-testid="button-notifications">
          <i className="fas fa-bell"></i>
          <span className="absolute -top-1 -right-1 bg-destructive text-destructive-foreground text-xs rounded-full w-5 h-5 flex items-center justify-center">
            3
          </span>
        </Button>
        
        {/* Quick Actions */}
        <Button variant="ghost" size="sm" className="p-2 lg:hidden" data-testid="button-quick-actions">
          <i className="fas fa-plus"></i>
        </Button>
      </div>
    </header>
  );
}
