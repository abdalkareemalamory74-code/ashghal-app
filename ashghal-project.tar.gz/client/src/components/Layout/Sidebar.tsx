import { Link, useLocation } from "wouter";
import { useAuth } from "../../context/AuthContext";
import { Button } from "@/components/ui/button";

interface SidebarProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function Sidebar({ isOpen, onClose }: SidebarProps) {
  const [location] = useLocation();
  const { userProfile, logout } = useAuth();

  if (!userProfile) return null;

  const handleLogout = async () => {
    await logout();
    onClose();
  };

  const navItems = [
    { path: "/dashboard", label: "لوحة التحكم", icon: "fas fa-tachometer-alt", roles: ['user', 'worker', 'admin'] },
    { path: "/my-requests", label: "طلباتي", icon: "fas fa-clipboard-list", roles: ['user'] },
    { path: "/create-request", label: "طلب جديد", icon: "fas fa-plus-circle", roles: ['user'] },
    { path: "/worker-dashboard", label: "الطلبات المتاحة", icon: "fas fa-hammer", roles: ['worker'] },
    { path: "/admin-panel", label: "لوحة الإدارة", icon: "fas fa-cog", roles: ['admin'] }
  ];

  const filteredNavItems = navItems.filter(item => 
    item.roles.includes(userProfile.role)
  );

  return (
    <aside 
      className={`bg-sidebar border-l border-sidebar-border w-64 flex-shrink-0 sidebar-transition lg:translate-x-0 ${
        isOpen ? 'translate-x-0' : 'translate-x-full'
      } fixed lg:relative z-30 h-full`}
      data-testid="sidebar"
    >
      <div className="flex flex-col h-full">
        {/* Logo Section */}
        <div className="mobile-padding border-b border-sidebar-border">
          <div className="flex items-center space-x-3 space-x-reverse">
            <div className="w-10 h-10 bg-sidebar-primary rounded-lg flex items-center justify-center">
              <i className="fas fa-tools text-sidebar-primary-foreground text-lg"></i>
            </div>
            <div>
              <h1 className="text-xl font-bold text-sidebar-foreground">أشغال</h1>
              <p className="text-sm text-muted-foreground">الخدمات الميدانية</p>
            </div>
          </div>
        </div>
        
        {/* Navigation Menu */}
        <nav className="flex-1 mobile-padding mobile-space-y">
          {filteredNavItems.map((item) => (
            <Link key={item.path} href={item.path}>
              <a 
                className={`flex items-center space-x-3 space-x-reverse p-3 rounded-md transition-colors ${
                  location === item.path
                    ? 'bg-sidebar-primary text-sidebar-primary-foreground'
                    : 'hover:bg-sidebar-accent hover:text-sidebar-accent-foreground'
                }`}
                onClick={onClose}
                data-testid={`nav-${item.path.replace('/', '')}`}
              >
                <i className={`${item.icon} w-5`}></i>
                <span>{item.label}</span>
              </a>
            </Link>
          ))}
        </nav>
        
        {/* User Profile Section */}
        <div className="mobile-padding border-t border-sidebar-border">
          <div className="flex items-center space-x-3 space-x-reverse mb-3">
            <div className="w-10 h-10 bg-muted rounded-full flex items-center justify-center">
              <i className="fas fa-user text-muted-foreground"></i>
            </div>
            <div className="flex-1">
              <p className="font-medium text-sidebar-foreground" data-testid="user-name">
                {userProfile.name}
              </p>
              <p className="text-sm text-muted-foreground" data-testid="user-role">
                {userProfile.role === 'user' ? 'مستخدم' : 
                 userProfile.role === 'worker' ? 'مقاول' : 'مدير'}
              </p>
            </div>
          </div>
          <Button 
            variant="secondary" 
            className="w-full justify-center space-x-2 space-x-reverse"
            onClick={handleLogout}
            data-testid="button-logout"
          >
            <i className="fas fa-sign-out-alt"></i>
            <span>تسجيل خروج</span>
          </Button>
        </div>
      </div>
    </aside>
  );
}
