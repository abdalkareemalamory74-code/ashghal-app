import { useState, useCallback, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { X, Upload, Image as ImageIcon, AlertTriangle } from 'lucide-react';
import { cn } from '@/lib/utils';
import { uploadImage, deleteImage } from '@/lib/firebase-storage';

interface ImageFile {
  id: string;
  file: File;
  url: string;
  uploadUrl?: string;
  uploading?: boolean;
  progress?: number;
  error?: string;
}

interface ImageUploadProps {
  value?: string[]; // Array of uploaded image URLs
  onChange?: (urls: string[]) => void;
  maxImages?: number;
  maxSize?: number; // in MB
  acceptedTypes?: string[];
  className?: string;
  disabled?: boolean;
  userId: string; // Required for Firebase Storage path
  postId?: string; // Optional, for organizing images
}

export function ImageUpload({
  value = [],
  onChange,
  maxImages = 5,
  maxSize = 5, // 5MB default
  acceptedTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/webp'],
  className,
  disabled = false,
  userId,
  postId = 'temp'
}: ImageUploadProps) {
  const [imageFiles, setImageFiles] = useState<ImageFile[]>([]);
  const [isDragging, setIsDragging] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const generateId = () => Math.random().toString(36).substr(2, 9);

  const validateFile = (file: File): string | null => {
    if (!acceptedTypes.includes(file.type)) {
      return `نوع الملف غير مدعوم. الأنواع المدعومة: ${acceptedTypes.join(', ')}`;
    }
    if (file.size > maxSize * 1024 * 1024) {
      return `حجم الملف كبير جداً. الحد الأقصى: ${maxSize}MB`;
    }
    return null;
  };

  const handleFiles = useCallback(async (files: FileList | File[]) => {
    if (disabled) return;

    const filesArray = Array.from(files);
    const totalImages = value.length + imageFiles.length + filesArray.length;
    
    if (totalImages > maxImages) {
      alert(`لا يمكن رفع أكثر من ${maxImages} صور`);
      return;
    }

    const newImageFiles: ImageFile[] = [];

    for (const file of filesArray) {
      const error = validateFile(file);
      if (error) {
        alert(error);
        continue;
      }

      const id = generateId();
      const imageFile: ImageFile = {
        id,
        file,
        url: URL.createObjectURL(file),
        uploading: true,
        progress: 0
      };
      newImageFiles.push(imageFile);
    }

    setImageFiles(prev => [...prev, ...newImageFiles]);

    // Start uploading files
    for (const imageFile of newImageFiles) {
      try {
        const uploadUrl = await uploadImage(
          imageFile.file,
          userId,
          postId,
          (progress) => {
            setImageFiles(prev => prev.map(img => 
              img.id === imageFile.id 
                ? { ...img, progress }
                : img
            ));
          }
        );

        setImageFiles(prev => prev.map(img => 
          img.id === imageFile.id 
            ? { ...img, uploadUrl, uploading: false, progress: 100 }
            : img
        ));

        // Update parent component with new URLs
        if (onChange) {
          const newUrls = [...value, uploadUrl];
          onChange(newUrls);
        }

      } catch (error) {
        console.error('Error uploading image:', error);
        setImageFiles(prev => prev.map(img => 
          img.id === imageFile.id 
            ? { ...img, uploading: false, error: 'فشل في رفع الصورة' }
            : img
        ));
      }
    }
  }, [disabled, value, imageFiles.length, maxImages, maxSize, acceptedTypes, onChange, userId, postId]);

  const removeImage = async (index: number, isUploaded: boolean = false) => {
    if (disabled) return;

    if (isUploaded && value[index]) {
      try {
        await deleteImage(value[index]);
        const newUrls = value.filter((_, i) => i !== index);
        onChange?.(newUrls);
      } catch (error) {
        console.error('Error deleting image:', error);
        alert('فشل في حذف الصورة');
      }
    } else {
      // Remove from pending uploads
      const imageFile = imageFiles[index - value.length];
      if (imageFile) {
        URL.revokeObjectURL(imageFile.url);
        setImageFiles(prev => prev.filter(img => img.id !== imageFile.id));
      }
    }
  };

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);

    if (disabled) return;

    const files = e.dataTransfer.files;
    if (files.length > 0) {
      handleFiles(files);
    }
  }, [handleFiles, disabled]);

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
  }, []);

  const handleDragEnter = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(true);
  }, []);

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
  }, []);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files && files.length > 0) {
      handleFiles(files);
    }
    // Reset input value to allow re-selecting the same files
    e.target.value = '';
  };

  const totalImages = value.length + imageFiles.length;
  const canAddMore = totalImages < maxImages && !disabled;

  return (
    <div className={cn("space-y-4", className)}>
      {/* Upload Area */}
      {canAddMore && (
        <Card
          className={cn(
            "border-2 border-dashed transition-colors cursor-pointer",
            isDragging 
              ? "border-primary bg-primary/5" 
              : "border-muted-foreground/25 hover:border-primary/50",
            disabled && "opacity-50 cursor-not-allowed"
          )}
          onDrop={handleDrop}
          onDragOver={handleDragOver}
          onDragEnter={handleDragEnter}
          onDragLeave={handleDragLeave}
          onClick={() => !disabled && fileInputRef.current?.click()}
          data-testid="image-upload-area"
        >
          <CardContent className="p-8 text-center">
            <Upload className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
            <h3 className="text-lg font-medium text-foreground mb-2">
              اسحب الصور هنا أو انقر للاختيار
            </h3>
            <p className="text-sm text-muted-foreground mb-2">
              أنواع الملفات المدعومة: JPG, PNG, WEBP
            </p>
            <p className="text-xs text-muted-foreground">
              حد أقصى {maxSize}MB لكل صورة • حد أقصى {maxImages} صور
            </p>
            <Badge variant="outline" className="mt-2">
              {totalImages} / {maxImages} صور
            </Badge>
          </CardContent>
        </Card>
      )}

      {/* Hidden File Input */}
      <input
        ref={fileInputRef}
        type="file"
        multiple
        accept={acceptedTypes.join(',')}
        onChange={handleInputChange}
        className="hidden"
        disabled={disabled}
      />

      {/* Uploaded Images Grid */}
      {(value.length > 0 || imageFiles.length > 0) && (
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4" data-testid="uploaded-images">
          {/* Already uploaded images */}
          {value.map((url, index) => (
            <div key={url} className="relative group">
              <Card className="overflow-hidden">
                <CardContent className="p-0 aspect-square">
                  <img
                    src={url}
                    alt={`صورة ${index + 1}`}
                    className="w-full h-full object-cover"
                    data-testid={`uploaded-image-${index}`}
                  />
                </CardContent>
              </Card>
              {!disabled && (
                <Button
                  size="sm"
                  variant="destructive"
                  className="absolute -top-2 -right-2 h-6 w-6 p-0 rounded-full opacity-0 group-hover:opacity-100 transition-opacity"
                  onClick={() => removeImage(index, true)}
                  data-testid={`remove-uploaded-image-${index}`}
                >
                  <X className="h-3 w-3" />
                </Button>
              )}
            </div>
          ))}

          {/* Uploading/Pending images */}
          {imageFiles.map((imageFile, index) => (
            <div key={imageFile.id} className="relative group">
              <Card className="overflow-hidden">
                <CardContent className="p-0 aspect-square">
                  <div className="relative w-full h-full">
                    <img
                      src={imageFile.url}
                      alt={`صورة ${value.length + index + 1}`}
                      className="w-full h-full object-cover"
                      data-testid={`pending-image-${index}`}
                    />
                    
                    {/* Upload Progress Overlay */}
                    {imageFile.uploading && (
                      <div className="absolute inset-0 bg-black/50 flex flex-col items-center justify-center">
                        <div className="w-full px-2">
                          <Progress 
                            value={imageFile.progress || 0} 
                            className="mb-2" 
                          />
                          <p className="text-white text-xs text-center">
                            {Math.round(imageFile.progress || 0)}% جاري الرفع...
                          </p>
                        </div>
                      </div>
                    )}

                    {/* Error Overlay */}
                    {imageFile.error && (
                      <div className="absolute inset-0 bg-destructive/80 flex flex-col items-center justify-center">
                        <AlertTriangle className="h-8 w-8 text-white mb-2" />
                        <p className="text-white text-xs text-center px-2">
                          {imageFile.error}
                        </p>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
              
              {!disabled && !imageFile.uploading && (
                <Button
                  size="sm"
                  variant="destructive"
                  className="absolute -top-2 -right-2 h-6 w-6 p-0 rounded-full opacity-0 group-hover:opacity-100 transition-opacity"
                  onClick={() => removeImage(value.length + index, false)}
                  data-testid={`remove-pending-image-${index}`}
                >
                  <X className="h-3 w-3" />
                </Button>
              )}
            </div>
          ))}
        </div>
      )}

      {/* Images Info */}
      {totalImages === 0 && (
        <div className="text-center py-8">
          <ImageIcon className="h-12 w-12 text-muted-foreground mx-auto mb-2" />
          <p className="text-muted-foreground">لم يتم رفع أي صور بعد</p>
        </div>
      )}
    </div>
  );
}