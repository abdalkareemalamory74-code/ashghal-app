import { useState, useEffect, useMemo } from "react";
import { useLocation, useParams, Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { ArrowRight, ChevronLeft, MapPin, Calendar, Star, Phone, User } from "lucide-react";
import { 
  MAIN_CATEGORIES, 
  SERVICE_CATEGORIES, 
  REAL_ESTATE_CATEGORIES, 
  VEHICLE_CATEGORIES, 
  PRODUCT_CATEGORIES, 
  JOB_CATEGORIES,
  CITIES, 
  POST_TYPES, 
  REQUEST_STATUSES 
} from "../utils/constants";
import { useAuth } from "../context/AuthContext";
import AppLayout from "../components/Layout/AppLayout";
import { Post, PostType, MainCategory, RequestStatus } from "@shared/schema";

interface SubCategoryParams {
  category: string;
  subcategory: string;
}

export default function SubCategory() {
  const params = useParams<SubCategoryParams>();
  const [, setLocation] = useLocation();
  const { userProfile } = useAuth();
  
  const mainCategoryKey = params.category;
  const subCategoryKey = params.subcategory;
  const mainCategoryName = MAIN_CATEGORIES[mainCategoryKey as keyof typeof MAIN_CATEGORIES];
  
  // حالة جديدة لاختيار مطلوب أو معروض
  const [selectedAdType, setSelectedAdType] = useState<string>('');
  
  // الحصول على الفئات الفرعية حسب الفئة الرئيسية
  const getSubCategories = (mainCategory: string): Record<string, string> => {
    switch(mainCategory) {
      case 'real_estate': return REAL_ESTATE_CATEGORIES;
      case 'vehicles': return VEHICLE_CATEGORIES;
      case 'services': return SERVICE_CATEGORIES;
      case 'products': return PRODUCT_CATEGORIES;
      case 'jobs': return JOB_CATEGORIES;
      default: return {};
    }
  };
  
  const subCategories = getSubCategories(mainCategoryKey || '');
  const subCategoryName = subCategories[subCategoryKey || ''];
  
  // حالات الفلترة والترتيب
  const [selectedCity, setSelectedCity] = useState('all');
  const [selectedStatus, setSelectedStatus] = useState('all');
  const [sortBy, setSortBy] = useState('recent');

  // التحقق من صحة الفئة والفئة الفرعية
  useEffect(() => {
    if (!mainCategoryKey || !mainCategoryName || !subCategoryKey || !subCategoryName) {
      setLocation('/');
    }
  }, [mainCategoryKey, mainCategoryName, subCategoryKey, subCategoryName, setLocation]);

  // جلب بيانات الفئة الفرعية
  const { data: subCategoryPosts, isLoading } = useQuery({
    queryKey: ['subcategory', mainCategoryKey, subCategoryKey, selectedAdType, selectedCity, selectedStatus, sortBy],
    queryFn: (): Promise<Post[]> => {
      return new Promise(resolve => {
        setTimeout(() => {
          let mockPosts: Post[] = [];
          
          // Generate mock posts based on main category and subcategory
          if (mainCategoryKey === 'services') {
            const servicePosts = [
              {
                id: '1',
                userId: 'user-1',
                title: 'كهربائي ماهر - إصلاح جميع الأعطال الكهربائية',
                description: 'كهربائي بخبرة 15 سنة في إصلاح الأعطال الكهربائية، تركيب اللوحات والمفاتيح، صيانة الأجهزة',
                mainCategory: 'services',
                category: 'electrical',
                city: 'damascus',
                postType: 'service_offer',
                status: 'open',
                price: 15000,
                createdAt: new Date('2024-03-10'),
                userPhone: '0944123456',
                userName: 'أحمد محمد',
                photos: ['https://images.unsplash.com/photo-1621905251189-08b45d6a269e?w=400&h=300&fit=crop', 'https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=400&h=300&fit=crop'],
                rating: 4.8,
                completedJobs: 150,
                experience: 15
              },
              {
                id: '2',
                userId: 'user-2', 
                title: 'مطلوب كهربائي للطوارئ - منطقة المالكي',
                description: 'نحتاج كهربائي لإصلاح عطل عاجل في المنزل، انقطاع التيار في غرفتين',
                mainCategory: 'services',
                category: 'electrical',
                city: 'damascus',
                postType: 'service_request',
                status: 'open',
                budget: 25000,
                createdAt: new Date('2024-03-12'),
                userPhone: '0987654321',
                userName: 'سارة أحمد',
                photos: ['https://images.unsplash.com/photo-1558618047-3c8c76ca7d13?w=400&h=300&fit=crop'],
                isEmergency: true
              },
              {
                id: '3',
                userId: 'user-3',
                title: 'سباك محترف - تسليك وإصلاح',
                description: 'خدمات سباكة شاملة، تسليك المجاري، إصلاح التسريبات، تركيب الأدوات الصحية',
                mainCategory: 'services',
                category: 'plumbing',
                city: 'aleppo',
                postType: 'service_offer',
                status: 'open',
                price: 12000,
                createdAt: new Date('2024-03-11'),
                userPhone: '0933111222',
                userName: 'محمد علي',
                photos: ['https://images.unsplash.com/photo-1607472586893-edb57bdc0e39?w=400&h=300&fit=crop', 'https://images.unsplash.com/photo-1584464491033-06628f3a6b7b?w=400&h=300&fit=crop'],
                rating: 4.5,
                completedJobs: 95
              },
              {
                id: '4',
                userId: 'user-4',
                title: 'مطلوب دهان للمنزل - عمل نظيف',
                description: 'نحتاج دهان محترف لدهان المنزل، 4 غرف وصالون، ألوان حديثة',
                mainCategory: 'services',
                category: 'painting',
                city: 'damascus',
                postType: 'service_request',
                status: 'open',
                budget: 300000,
                createdAt: new Date('2024-03-09'),
                userPhone: '0911333444',
                userName: 'فاطمة أحمد',
                photos: ['https://images.unsplash.com/photo-1562259949-e8e7689d7828?w=400&h=300&fit=crop']
              },
              {
                id: '13',
                userId: 'user-13',
                title: 'نجار ماهر - تفصيل وتركيب',
                description: 'نجار بخبرة 12 سنة، تفصيل أثاث، تركيب مطابخ، أعمال ديكور خشبي',
                mainCategory: 'services',
                category: 'carpentry',
                city: 'homs',
                postType: 'service_offer',
                status: 'open',
                price: 18000,
                createdAt: new Date('2024-03-08'),
                userPhone: '0966777333',
                userName: 'خالد النجار',
                photos: ['https://images.unsplash.com/photo-1416879595882-3373a0480b5b?w=400&h=300&fit=crop'],
                rating: 4.7,
                completedJobs: 80
              },
              {
                id: '14',
                userId: 'user-14',
                title: 'مطلوب صيانة تكييف مركزي',
                description: 'صيانة دورية لنظام التكييف المركزي في مبنى تجاري، عقد سنوي',
                mainCategory: 'services',
                category: 'ac_cooling',
                city: 'damascus',
                postType: 'service_request',
                status: 'open',
                budget: 500000,
                createdAt: new Date('2024-03-07'),
                userPhone: '0944666222',
                userName: 'شركة البناء',
                photos: []
              }
            ];
            mockPosts = (servicePosts as Post[]).filter(post => post.category === subCategoryKey);
          } else if (mainCategoryKey === 'real_estate') {
            const realEstatePosts = [
              {
                id: '5',
                userId: 'user-5',
                title: 'شقة للبيع - دمشق الجديدة',
                description: 'شقة 3 غرف، 2 حمام، مساحة 120 متر، الطابق الثالث، مصعد',
                mainCategory: 'real_estate',
                category: 'apartments',
                city: 'damascus',
                postType: 'real_estate_sale',
                status: 'open',
                price: 45000000,
                createdAt: new Date('2024-03-10'),
                userPhone: '0944555666',
                userName: 'أحمد العقاري',
                photos: [],
                area: 120,
                rooms: 3,
                bathrooms: 2,
                floor: 3,
                elevator: true
              },
              {
                id: '6',
                userId: 'user-6',
                title: 'منزل للإيجار - حي الزهراء',
                description: 'منزل مستقل، 4 غرف، حديقة صغيرة، موقف سيارة',
                mainCategory: 'real_estate',
                category: 'houses',
                city: 'aleppo',
                postType: 'real_estate_rent',
                status: 'open',
                price: 180000,
                createdAt: new Date('2024-03-08'),
                userPhone: '0987777888',
                userName: 'سامر العقار',
                photos: [],
                rooms: 4,
                parking: true,
                garden: true
              },
              {
                id: '15',
                userId: 'user-15',
                title: 'محل تجاري للبيع - شارع البحصة',
                description: 'محل تجاري بموقع مميز، مساحة 80 متر، واجهة على الشارع الرئيسي',
                mainCategory: 'real_estate',
                category: 'shops',
                city: 'aleppo',
                postType: 'real_estate_sale',
                status: 'open',
                price: 25000000,
                createdAt: new Date('2024-03-09'),
                userPhone: '0933444555',
                userName: 'مكتب العقارات الذهبية',
                photos: [],
                area: 80
              },
              {
                id: '16',
                userId: 'user-16',
                title: 'مكتب للإيجار - منطقة أبو رمانة',
                description: 'مكتب في برج تجاري، 5 غرف، استقبال، مصعد، موقف',
                mainCategory: 'real_estate',
                category: 'offices',
                city: 'damascus',
                postType: 'real_estate_rent',
                status: 'open',
                price: 350000,
                createdAt: new Date('2024-03-06'),
                userPhone: '0911888999',
                userName: 'مكتب الرمان العقاري',
                photos: [],
                rooms: 5,
                elevator: true,
                parking: true
              }
            ];
            mockPosts = (realEstatePosts as Post[]).filter(post => post.category === subCategoryKey);
          } else if (mainCategoryKey === 'vehicles') {
            const vehiclePosts = [
              {
                id: '7',
                userId: 'user-7',
                title: 'كيا سيراتو 2018 للبيع',
                description: 'سيارة نظيفة جداً، كيلومتر قليل، فحص كامل',
                mainCategory: 'vehicles',
                category: 'cars',
                city: 'damascus',
                postType: 'vehicle_sale',
                status: 'open',
                price: 12500000,
                createdAt: new Date('2024-03-09'),
                userPhone: '0933777888',
                userName: 'محمد السيارات',
                photos: [],
                brand: 'Kia',
                model: 'Cerato',
                year: 2018,
                mileage: 85000,
                condition: 'used'
              },
              {
                id: '8',
                userId: 'user-8',
                title: 'دراجة نارية ياماها للبيع',
                description: 'دراجة نارية ياماها 150cc، حالة ممتازة، استعمال شخصي',
                mainCategory: 'vehicles',
                category: 'motorcycles',
                city: 'homs',
                postType: 'vehicle_sale',
                status: 'open',
                price: 1800000,
                createdAt: new Date('2024-03-07'),
                userPhone: '0944888999',
                userName: 'علي الدراجات',
                photos: [],
                brand: 'Yamaha',
                condition: 'used'
              },
              {
                id: '17',
                userId: 'user-17',
                title: 'شاحنة هيونداي للبيع',
                description: 'شاحنة هيونداي 2015، حمولة 7 طن، حالة ممتازة، استعمال تجاري',
                mainCategory: 'vehicles',
                category: 'trucks',
                city: 'aleppo',
                postType: 'vehicle_sale',
                status: 'open',
                price: 18000000,
                createdAt: new Date('2024-03-05'),
                userPhone: '0987333444',
                userName: 'أبو أحمد الشاحنات',
                photos: [],
                brand: 'Hyundai',
                year: 2015
              }
            ];
            mockPosts = (vehiclePosts as Post[]).filter(post => post.category === subCategoryKey);
          } else if (mainCategoryKey === 'jobs') {
            const jobPosts = [
              {
                id: '9',
                userId: 'user-9',
                title: 'مطلوب مهندس برمجيات - دوام كامل',
                description: 'شركة تقنية تبحث عن مطور React.js خبرة 3+ سنوات',
                mainCategory: 'jobs',
                category: 'technology',
                city: 'damascus',
                postType: 'job_offer',
                status: 'open',
                salary: 1500000,
                createdAt: new Date('2024-03-08'),
                userPhone: '0911999000',
                userName: 'شركة التقنية الحديثة',
                photos: [],
                jobType: 'full_time',
                experienceRequired: 3,
                companyName: 'شركة التقنية الحديثة'
              },
              {
                id: '10',
                userId: 'user-10',
                title: 'مدرس رياضيات يبحث عن وظيفة',
                description: 'مدرس رياضيات خبرة 10 سنوات، إجازة في الرياضيات',
                mainCategory: 'jobs',
                category: 'education',
                city: 'aleppo',
                postType: 'job_request',
                status: 'open',
                createdAt: new Date('2024-03-06'),
                userPhone: '0987123456',
                userName: 'أحمد المدرس',
                photos: [],
                experience: 10
              },
              {
                id: '18',
                userId: 'user-18',
                title: 'مطلوب طبيب عام - عيادة خاصة',
                description: 'عيادة طبية تبحث عن طبيب عام، دوام مسائي، راتب مجزي',
                mainCategory: 'jobs',
                category: 'medicine',
                city: 'homs',
                postType: 'job_offer',
                status: 'open',
                salary: 2000000,
                createdAt: new Date('2024-03-04'),
                userPhone: '0955666777',
                userName: 'عيادة الشفاء',
                photos: [],
                jobType: 'part_time'
              }
            ];
            mockPosts = (jobPosts as Post[]).filter(post => post.category === subCategoryKey);
          } else if (mainCategoryKey === 'products') {
            const productPosts = [
              {
                id: '11',
                userId: 'user-11',
                title: 'لابتوب Dell للبيع - حالة ممتازة',
                description: 'لابتوب Dell Inspiron، معالج i7، رام 16GB، استخدام شخصي',
                mainCategory: 'products',
                category: 'electronics',
                city: 'aleppo',
                postType: 'product_sale',
                status: 'open',
                price: 850000,
                createdAt: new Date('2024-03-07'),
                userPhone: '0987111222',
                userName: 'سامر التقنية',
                photos: [],
                brand_product: 'Dell',
                condition_product: 'excellent',
                warranty: false
              },
              {
                id: '12',
                userId: 'user-12',
                title: 'طقم أثاث غرفة جلوس للبيع',
                description: 'طقم أثاث كامل، حالة جيدة، 3+2+1، لون بيج',
                mainCategory: 'products',
                category: 'furniture',
                city: 'damascus',
                postType: 'product_sale',
                status: 'open',
                price: 750000,
                createdAt: new Date('2024-03-05'),
                userPhone: '0944333555',
                userName: 'خالد الأثاث',
                photos: [],
                condition_product: 'good'
              },
              {
                id: '19',
                userId: 'user-19',
                title: 'هاتف آيفون 13 للبيع',
                description: 'آيفون 13، 128 جيجا، لون أزرق، حالة ممتازة مع الكرتون',
                mainCategory: 'products',
                category: 'electronics',
                city: 'damascus',
                postType: 'product_sale',
                status: 'open',
                price: 1200000,
                createdAt: new Date('2024-03-03'),
                userPhone: '0944777111',
                userName: 'متجر الهواتف',
                photos: [],
                brand_product: 'Apple',
                condition_product: 'excellent'
              }
            ];
            mockPosts = (productPosts as Post[]).filter(post => post.category === subCategoryKey);
          }
          
          // فلترة البيانات حسب المعايير المحددة
          let filtered = mockPosts.filter(post => {
            const matchesCity = selectedCity === 'all' || post.city === selectedCity;
            const matchesStatus = selectedStatus === 'all' || post.status === selectedStatus;
            
            // فلترة حسب نوع الإعلان (مطلوب/معروض)
            let matchesAdType = true;
            if (selectedAdType) {
              const wantedTypes = ['service_request', 'job_request', 'real_estate_wanted', 'vehicle_wanted', 'product_wanted'];
              const offeredTypes = ['service_offer', 'job_offer', 'real_estate_sale', 'real_estate_rent', 'vehicle_sale', 'product_sale'];
              
              if (selectedAdType === 'wanted') {
                matchesAdType = wantedTypes.includes(post.postType);
              } else if (selectedAdType === 'offered') {
                matchesAdType = offeredTypes.includes(post.postType);
              }
            }
            
            return matchesCity && matchesStatus && matchesAdType;
          });
          
          // ترتيب النتائج
          if (sortBy === 'price_low') {
            filtered.sort((a, b) => (a.price || 0) - (b.price || 0));
          } else if (sortBy === 'price_high') {
            filtered.sort((a, b) => (b.price || 0) - (a.price || 0));
          } else if (sortBy === 'rating') {
            filtered.sort((a, b) => (b.rating || 0) - (a.rating || 0));
          } else {
            // recent
            filtered.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
          }
          
          resolve(filtered);
        }, 300);
      });
    },
    enabled: !!mainCategoryKey && !!subCategoryKey && !!mainCategoryName && !!subCategoryName
  });

  // أيقونات الفئات الفرعية
  const subCategoryIcons: Record<string, string> = {
    // الخدمات
    electrical: "fas fa-bolt",
    plumbing: "fas fa-wrench", 
    painting: "fas fa-paint-roller",
    construction: "fas fa-hard-hat",
    carpentry: "fas fa-hammer",
    aluminum: "fas fa-window-maximize",
    ac_cooling: "fas fa-snowflake",
    blacksmith: "fas fa-fire",
    well_drilling: "fas fa-tint",
    maintenance: "fas fa-screwdriver",
    transport: "fas fa-truck",
    cleaning: "fas fa-broom",
    gardening: "fas fa-seedling",
    security: "fas fa-shield-alt",
    catering: "fas fa-utensils",
    education: "fas fa-chalkboard-teacher",
    technology: "fas fa-laptop-code",
    health: "fas fa-stethoscope",
    legal: "fas fa-balance-scale",
    
    // العقارات
    apartments: "fas fa-building",
    houses: "fas fa-home",
    villas: "fas fa-house-user",
    offices: "fas fa-briefcase",
    shops: "fas fa-store",
    warehouses: "fas fa-warehouse",
    lands: "fas fa-map",
    farms: "fas fa-tractor",
    
    // المركبات
    cars: "fas fa-car",
    motorcycles: "fas fa-motorcycle",
    trucks: "fas fa-truck",
    buses: "fas fa-bus",
    boats: "fas fa-ship",
    bicycles: "fas fa-bicycle",
    spare_parts: "fas fa-cog",
    accessories: "fas fa-tools",
    
    // المنتجات
    electronics: "fas fa-mobile-alt",
    appliances: "fas fa-tv",
    furniture: "fas fa-couch",
    clothing: "fas fa-tshirt",
    books: "fas fa-book",
    sports: "fas fa-football-ball",
    toys: "fas fa-gamepad",
    jewelry: "fas fa-gem",
    cosmetics: "fas fa-spray-can",
    food: "fas fa-apple-alt",
    tools: "fas fa-toolbox",
    art: "fas fa-palette",
    medical: "fas fa-first-aid",
    baby: "fas fa-baby",
    pets: "fas fa-paw",
    garden: "fas fa-leaf",
    
    // الوظائف
    engineering: "fas fa-drafting-compass",
    medicine: "fas fa-user-md",
    finance: "fas fa-chart-line",
    marketing: "fas fa-bullhorn",
    management: "fas fa-users",
    arts: "fas fa-paint-brush",
    media: "fas fa-newspaper",
    hospitality: "fas fa-concierge-bell",
    transportation: "fas fa-shipping-fast",
    retail: "fas fa-shopping-cart",
    manufacturing: "fas fa-industry",
    agriculture: "fas fa-wheat",
    food_service: "fas fa-hamburger",
    
    other: "fas fa-ellipsis-h"
  };

  const formatDate = (date: Date | string) => {
    const dateObj = typeof date === 'string' ? new Date(date) : date;
    return dateObj.toLocaleDateString('ar-SY', {
      year: 'numeric',
      month: 'long', 
      day: 'numeric'
    });
  };

  const formatPrice = (price?: number) => {
    if (!price) return '';
    return new Intl.NumberFormat('ar-SY').format(price) + ' ل.س';
  };

  const getPostTypeColor = (type: string) => {
    switch(type) {
      case 'service_offer': return 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200';
      case 'job_offer': return 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200';
      case 'service_request': return 'bg-orange-100 text-orange-800 dark:bg-orange-900 dark:text-orange-200';
      case 'job_request': return 'bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-200';
      case 'real_estate_sale': return 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200';
      case 'real_estate_rent': return 'bg-teal-100 text-teal-800 dark:bg-teal-900 dark:text-teal-200';
      case 'vehicle_sale': return 'bg-indigo-100 text-indigo-800 dark:bg-indigo-900 dark:text-indigo-200';
      case 'product_sale': return 'bg-pink-100 text-pink-800 dark:bg-pink-900 dark:text-pink-200';
      default: return 'bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-200';
    }
  };

  const getPostTypeText = (type: string) => {
    const typeTexts: Record<string, string> = {
      'service_offer': 'عرض خدمة',
      'service_request': 'طلب خدمة',
      'job_offer': 'عرض عمل',
      'job_request': 'طلب عمل',
      'real_estate_sale': 'للبيع',
      'real_estate_rent': 'للإيجار',
      'vehicle_sale': 'للبيع',
      'product_sale': 'للبيع'
    };
    return typeTexts[type] || type;
  };

  if (!mainCategoryKey || !mainCategoryName || !subCategoryKey || !subCategoryName) {
    return null;
  }

  // إذا لم يتم اختيار نوع الإعلان بعد، عرض خيارات مطلوب/معروض
  if (!selectedAdType) {
    return (
      <AppLayout>
        <div className="mobile-container mobile-padding">
          {/* مسار التنقل */}
          <div className="flex items-center gap-2 text-sm text-muted-foreground mb-6">
            <Link href="/" className="hover:text-primary transition-colors">
              الرئيسية
            </Link>
            <ChevronLeft className="w-4 h-4" />
            <Link href={`/category/${mainCategoryKey}`} className="hover:text-primary transition-colors">
              {mainCategoryName}
            </Link>
            <ChevronLeft className="w-4 h-4" />
            <span className="text-foreground font-medium">{subCategoryName}</span>
          </div>

          {/* عنوان الفئة الفرعية */}
          <div className="text-center mb-8">
            <div className="w-24 h-24 bg-gradient-to-br from-primary/20 to-primary/10 rounded-xl flex items-center justify-center mx-auto mb-4">
              <i className={`${subCategoryIcons[subCategoryKey]} text-primary text-3xl`}></i>
            </div>
            <h1 className="text-3xl font-bold text-foreground mb-2">{subCategoryName}</h1>
            <p className="text-muted-foreground">
              اختر نوع الإعلان لعرض المحتوى المناسب
            </p>
          </div>

          {/* خيارات مطلوب/معروض */}
          <div className="mobile-card-grid max-w-2xl mx-auto">
            {/* مطلوب */}
            <Card 
              className="p-6 border-2 border-green-200 bg-green-50/50 hover:shadow-lg transition-all cursor-pointer hover:scale-105"
              onClick={() => setSelectedAdType('wanted')}
            >
              <CardContent className="text-center p-0">
                <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <i className="fas fa-search text-green-600 text-2xl"></i>
                </div>
                <h3 className="text-xl font-semibold text-green-800 mb-2">مطلوب</h3>
                <p className="text-green-700 text-sm">
                  عرض الطلبات والبحث عن خدمات
                </p>
              </CardContent>
            </Card>

            {/* معروض */}
            <Card 
              className="p-6 border-2 border-blue-200 bg-blue-50/50 hover:shadow-lg transition-all cursor-pointer hover:scale-105"
              onClick={() => setSelectedAdType('offered')}
            >
              <CardContent className="text-center p-0">
                <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <i className="fas fa-megaphone text-blue-600 text-2xl"></i>
                </div>
                <h3 className="text-xl font-semibold text-blue-800 mb-2">معروض</h3>
                <p className="text-blue-700 text-sm">
                  عرض الخدمات والمنتجات المتاحة
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </AppLayout>
    );
  }

  return (
    <AppLayout>
      <div className="min-h-screen bg-background prevent-overflow" dir="rtl">
        <div className="mobile-container mobile-padding">
          {/* شريط التنقل */}
          <div className="flex flex-wrap items-center gap-2 mb-4 sm:mb-6 md:mb-8" data-testid="breadcrumb-nav">
            <Button 
              variant="outline" 
              size="sm"
              onClick={() => setLocation('/')}
              className="flex items-center gap-2"
              data-testid="button-back-home"
            >
              <ChevronLeft className="h-4 w-4" />
              الرئيسية
            </Button>
            <ArrowRight className="h-4 w-4 text-muted-foreground" />
            <Button 
              variant="outline" 
              size="sm"
              onClick={() => setLocation(`/category/${mainCategoryKey}`)}
              className="text-muted-foreground hover:text-foreground"
              data-testid="button-back-category"
            >
              {mainCategoryName}
            </Button>
            <ArrowRight className="h-4 w-4 text-muted-foreground" />
            <span 
              className="text-muted-foreground hover:text-foreground cursor-pointer" 
              onClick={() => setSelectedAdType('')}
              data-testid="text-current-subcategory"
            >
              {subCategoryName}
            </span>
            <ArrowRight className="h-4 w-4 text-muted-foreground" />
            <span className="text-foreground font-medium">
              {selectedAdType === 'wanted' ? 'مطلوب' : 'معروض'}
            </span>
          </div>

          {/* العنوان والإحصائيات */}
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 sm:gap-6 mb-4 sm:mb-6 md:mb-8">
            <div className="flex items-center gap-4">
              <div className="w-16 h-16 bg-primary/10 rounded-2xl flex items-center justify-center">
                <i className={`${subCategoryIcons[subCategoryKey]} text-primary text-3xl`}></i>
              </div>
              <div>
                <h1 className="responsive-title font-bold text-foreground mb-2" data-testid="subcategory-title">
                  {subCategoryName}
                </h1>
                <p className="text-muted-foreground">
                  {isLoading ? 'جاري التحميل...' : `${subCategoryPosts?.length || 0} إعلان متاح`}
                </p>
              </div>
            </div>
          </div>

          {/* شريط الفلترة والترتيب */}
          <div className="mobile-filters mobile-padding bg-card rounded-xl border mb-4 sm:mb-6 md:mb-8">
            <div className="flex-1">
              <label className="text-sm font-medium mb-2 block" data-testid="label-city-filter">المدينة</label>
              <Select value={selectedCity} onValueChange={setSelectedCity}>
                <SelectTrigger data-testid="select-city">
                  <SelectValue placeholder="اختر المدينة" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">جميع المدن</SelectItem>
                  {Object.entries(CITIES).map(([key, name]) => (
                    <SelectItem key={key} value={key}>{name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div className="flex-1">
              <label className="text-sm font-medium mb-2 block" data-testid="label-status-filter">الحالة</label>
              <Select value={selectedStatus} onValueChange={setSelectedStatus}>
                <SelectTrigger data-testid="select-status">
                  <SelectValue placeholder="اختر الحالة" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">جميع الحالات</SelectItem>
                  {Object.entries(REQUEST_STATUSES).map(([key, name]) => (
                    <SelectItem key={key} value={key}>{name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div className="flex-1">
              <label className="text-sm font-medium mb-2 block" data-testid="label-sort">الترتيب</label>
              <Select value={sortBy} onValueChange={setSortBy}>
                <SelectTrigger data-testid="select-sort">
                  <SelectValue placeholder="اختر الترتيب" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="recent">الأحدث أولاً</SelectItem>
                  <SelectItem value="price_low">الأرخص أولاً</SelectItem>
                  <SelectItem value="price_high">الأغلى أولاً</SelectItem>
                  <SelectItem value="rating">الأعلى تقييماً</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* قائمة الإعلانات */}
          <div className="space-y-6">
            {isLoading ? (
              <div className="text-center py-16">
                <div className="w-16 h-16 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
                <p className="text-muted-foreground">جاري تحميل الإعلانات...</p>
              </div>
            ) : subCategoryPosts && subCategoryPosts.length > 0 ? (
              subCategoryPosts.map(post => (
                <Card key={post.id} className="hover:shadow-md transition-shadow overflow-hidden w-full" data-testid={`post-card-${post.id}`}>
                  <CardContent className="mobile-padding">
                    <div className="flex items-start gap-4 mb-4">
                      {/* صورة مصغرة */}
                      {post.photos && post.photos.length > 0 ? (
                        <div className="relative flex-shrink-0">
                          <img
                            src={post.photos[0]}
                            alt={post.title}
                            className="responsive-image w-16 h-16 sm:w-20 sm:h-20 md:w-24 md:h-24 object-cover rounded-lg border"
                            data-testid={`post-thumbnail-${post.id}`}
                          />
                          {post.photos.length > 1 && (
                            <div className="absolute -top-1 -right-1 w-6 h-6 bg-primary text-primary-foreground rounded-full flex items-center justify-center text-xs font-medium">
                              {post.photos.length}
                            </div>
                          )}
                        </div>
                      ) : (
                        <div className="w-16 h-16 sm:w-20 sm:h-20 md:w-24 md:h-24 bg-primary/10 rounded-lg flex items-center justify-center flex-shrink-0">
                          <i className={`${subCategoryIcons[post.category]} text-primary text-2xl`}></i>
                        </div>
                      )}
                      
                      {/* محتوى الإعلان */}
                      <div className="flex-1 min-w-0 overflow-hidden">
                        <div className="flex items-start justify-between mb-3">
                          <div className="flex-1 min-w-0 overflow-hidden">
                            <h3 className="font-semibold text-sm sm:text-base leading-tight mb-1 min-w-0 overflow-hidden text-ellipsis whitespace-nowrap" data-testid={`post-title-${post.id}`}>
                              {post.title}
                            </h3>
                            <div className="flex flex-col sm:flex-row sm:items-center gap-2 sm:gap-4 text-xs sm:text-sm text-muted-foreground">
                              <div className="flex items-center gap-1">
                                <User className="h-4 w-4" />
                                <span data-testid={`post-user-${post.id}`}>{post.userName}</span>
                              </div>
                              <div className="flex items-center gap-1">
                                <MapPin className="h-4 w-4" />
                                <span data-testid={`post-city-${post.id}`}>{CITIES[post.city as keyof typeof CITIES]}</span>
                              </div>
                              <div className="flex items-center gap-1">
                                <Calendar className="h-4 w-4" />
                                <span data-testid={`post-date-${post.id}`}>{formatDate(post.createdAt)}</span>
                              </div>
                            </div>
                          </div>
                          <div className="flex items-center gap-3">
                            <Badge 
                              className={getPostTypeColor(post.postType)}
                              data-testid={`post-type-badge-${post.id}`}
                            >
                              {getPostTypeText(post.postType)}
                            </Badge>
                            {post.isEmergency && (
                              <Badge className="bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200">
                                طوارئ
                              </Badge>
                            )}
                          </div>
                        </div>

                        <p className="text-sm text-muted-foreground leading-relaxed mb-4 min-w-0 overflow-hidden" style={{maxHeight: '3em', lineHeight: '1.5em', wordWrap: 'break-word'}} data-testid={`post-description-${post.id}`}>
                          {post.description}
                        </p>
                        
                        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
                          <div className="flex flex-col sm:flex-row sm:items-center gap-2 sm:gap-4 md:gap-6">
                        {post.price && (
                          <div className="text-2xl font-bold text-primary" data-testid={`post-price-${post.id}`}>
                            {formatPrice(post.price)}
                          </div>
                        )}
                        {post.budget && (
                          <div className="text-lg text-muted-foreground" data-testid={`post-budget-${post.id}`}>
                            الميزانية: {formatPrice(post.budget)}
                          </div>
                        )}
                        {post.salary && (
                          <div className="text-lg text-primary" data-testid={`post-salary-${post.id}`}>
                            الراتب: {formatPrice(post.salary)}
                          </div>
                        )}
                        {post.rating && (
                          <div className="flex items-center gap-1">
                            <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                            <span className="font-medium" data-testid={`post-rating-${post.id}`}>{post.rating}</span>
                            {post.completedJobs && (
                              <span className="text-sm text-muted-foreground">
                                ({post.completedJobs} عمل مكتمل)
                              </span>
                            )}
                          </div>
                        )}
                          </div>

                          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2">
                        <Button variant="outline" size="sm" className="mobile-button" data-testid={`button-contact-${post.id}`}>
                          <Phone className="h-4 w-4 ml-2" />
                          اتصال
                        </Button>
                        <Button size="sm" className="mobile-button" data-testid={`button-details-${post.id}`}>
                          تفاصيل أكثر
                        </Button>
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* معلومات إضافية حسب نوع الإعلان */}
                    {post.mainCategory === 'real_estate' && (
                      <div className="mt-4 pt-4 border-t">
                        <div className="flex items-center gap-6 text-sm text-muted-foreground">
                          {post.rooms && <span>الغرف: {post.rooms}</span>}
                          {post.bathrooms && <span>الحمامات: {post.bathrooms}</span>}
                          {post.area && <span>المساحة: {post.area} م²</span>}
                          {post.floor && <span>الطابق: {post.floor}</span>}
                          {post.elevator && <span>مصعد</span>}
                          {post.parking && <span>موقف سيارة</span>}
                          {post.garden && <span>حديقة</span>}
                        </div>
                      </div>
                    )}

                    {post.mainCategory === 'vehicles' && (
                      <div className="mt-4 pt-4 border-t">
                        <div className="flex items-center gap-6 text-sm text-muted-foreground">
                          {post.brand && <span>الماركة: {post.brand}</span>}
                          {post.model && <span>الموديل: {post.model}</span>}
                          {post.year && <span>السنة: {post.year}</span>}
                          {post.mileage && <span>الكيلومتر: {post.mileage}</span>}
                          {post.condition && <span>الحالة: {post.condition}</span>}
                        </div>
                      </div>
                    )}

                    {post.mainCategory === 'jobs' && (
                      <div className="mt-4 pt-4 border-t">
                        <div className="flex items-center gap-6 text-sm text-muted-foreground">
                          {post.jobType && <span>نوع الدوام: {post.jobType}</span>}
                          {post.experienceRequired && <span>الخبرة المطلوبة: {post.experienceRequired} سنوات</span>}
                          {post.experience && <span>الخبرة: {post.experience} سنوات</span>}
                          {post.companyName && <span>الشركة: {post.companyName}</span>}
                        </div>
                      </div>
                    )}

                    {post.mainCategory === 'products' && (
                      <div className="mt-4 pt-4 border-t">
                        <div className="flex items-center gap-6 text-sm text-muted-foreground">
                          {post.brand_product && <span>الماركة: {post.brand_product}</span>}
                          {post.condition_product && <span>الحالة: {post.condition_product}</span>}
                          {post.warranty !== undefined && <span>{post.warranty ? 'مع الضمان' : 'بدون ضمان'}</span>}
                        </div>
                      </div>
                    )}
                  </CardContent>
                </Card>
              ))
            ) : (
              <div className="text-center py-16">
                <div className="w-24 h-24 bg-muted rounded-full flex items-center justify-center mx-auto mb-6">
                  <i className={`${subCategoryIcons[subCategoryKey]} text-muted-foreground text-3xl`}></i>
                </div>
                <h3 className="text-xl font-semibold text-muted-foreground mb-2">
                  لا توجد إعلانات في هذا القسم
                </h3>
                <p className="text-muted-foreground mb-6">
                  كن أول من ينشر إعلان في {subCategoryName}
                </p>
                <Button 
                  onClick={() => setLocation('/create-request')}
                  data-testid="button-create-first-post"
                >
                  أنشئ إعلان جديد
                </Button>
              </div>
            )}
          </div>
        </div>
      </div>
    </AppLayout>
  );
}