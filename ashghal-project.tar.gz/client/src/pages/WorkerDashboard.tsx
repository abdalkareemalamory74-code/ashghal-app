import { useState } from "react";
import { useRequests } from "../context/RequestsContext";
import AppLayout from "../components/Layout/AppLayout";
import RequestCard from "../components/Requests/RequestCard";
import RequestDetailModal from "../components/Requests/RequestDetailModal";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ServiceRequest } from "../context/RequestsContext";

export default function WorkerDashboard() {
  const { availableRequests, acceptRequest, loading } = useRequests();
  const [selectedRequest, setSelectedRequest] = useState<ServiceRequest | null>(null);
  const [categoryFilter, setCategoryFilter] = useState<string>("all");
  const [accepting, setAccepting] = useState<string | null>(null);

  const filteredRequests = categoryFilter === "all" 
    ? availableRequests 
    : availableRequests.filter(request => request.category === categoryFilter);

  const handleAcceptRequest = async (requestId: string) => {
    setAccepting(requestId);
    try {
      await acceptRequest(requestId);
    } catch (error) {
      // Error handling is done in RequestsContext
    } finally {
      setAccepting(null);
    }
  };

  if (loading) {
    return (
      <AppLayout>
        <div className="flex items-center justify-center h-64">
          <div className="text-center">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-4"></div>
            <p className="text-muted-foreground">جاري تحميل الطلبات...</p>
          </div>
        </div>
      </AppLayout>
    );
  }

  return (
    <AppLayout>
      <div className="space-y-6" data-testid="worker-dashboard-page">
        {/* Header */}
        <div>
          <h1 className="text-2xl font-bold text-foreground mb-2">الطلبات المتاحة</h1>
          <p className="text-muted-foreground">
            اعرض واقبل الطلبات المتاحة في منطقتك
          </p>
        </div>

        {/* Filters */}
        <Card>
          <CardContent className="p-4">
            <div className="flex flex-wrap gap-4">
              <div className="flex items-center space-x-2 space-x-reverse">
                <label className="text-sm font-medium">الفئة:</label>
                <Select value={categoryFilter} onValueChange={setCategoryFilter}>
                  <SelectTrigger className="w-48" data-testid="select-category-filter">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">جميع الفئات</SelectItem>
                    <SelectItem value="plumbing">سباكة</SelectItem>
                    <SelectItem value="electrical">كهرباء</SelectItem>
                    <SelectItem value="ac">تكييف</SelectItem>
                    <SelectItem value="painting">دهان</SelectItem>
                    <SelectItem value="cleaning">تنظيف</SelectItem>
                    <SelectItem value="carpentry">نجارة</SelectItem>
                    <SelectItem value="other">أخرى</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="flex items-center space-x-2 space-x-reverse">
                <label className="text-sm font-medium">المنطقة:</label>
                <Select>
                  <SelectTrigger className="w-48" data-testid="select-area-filter">
                    <SelectValue placeholder="جميع المناطق" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">جميع المناطق</SelectItem>
                    <SelectItem value="riyadh">الرياض</SelectItem>
                    <SelectItem value="jeddah">جدة</SelectItem>
                    <SelectItem value="dammam">الدمام</SelectItem>
                    <SelectItem value="makkah">مكة</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <span className="text-sm text-muted-foreground self-center">
                ({filteredRequests.length} طلبات متاحة)
              </span>
            </div>
          </CardContent>
        </Card>

        {/* Available Requests */}
        <Card>
          <CardHeader>
            <CardTitle>الطلبات المتاحة</CardTitle>
          </CardHeader>
          <CardContent>
            {filteredRequests.length === 0 ? (
              <div className="text-center py-12" data-testid="no-available-requests">
                <i className="fas fa-search text-6xl text-muted-foreground mb-6"></i>
                <h3 className="text-lg font-semibold text-foreground mb-2">
                  لا توجد طلبات متاحة حالياً
                </h3>
                <p className="text-muted-foreground">
                  {categoryFilter === "all" 
                    ? "لا توجد طلبات جديدة في الوقت الحالي. تحقق مرة أخرى لاحقاً"
                    : "لا توجد طلبات في هذه الفئة. جرب تغيير الفلتر"
                  }
                </p>
              </div>
            ) : (
              <div className="space-y-4" data-testid="available-requests-list">
                {filteredRequests.map((request) => (
                  <RequestCard
                    key={request.id}
                    request={request}
                    onViewDetails={setSelectedRequest}
                    onAccept={(requestId) => {
                      if (accepting !== requestId) {
                        handleAcceptRequest(requestId);
                      }
                    }}
                  />
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      <RequestDetailModal
        request={selectedRequest}
        isOpen={!!selectedRequest}
        onClose={() => setSelectedRequest(null)}
      />
    </AppLayout>
  );
}
