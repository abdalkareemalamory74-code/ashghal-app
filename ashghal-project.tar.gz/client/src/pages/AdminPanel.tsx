import { useState } from "react";
import { useAuth } from "../context/AuthContext";
import { useRequests } from "../context/RequestsContext";
import AppLayout from "../components/Layout/AppLayout";
import RequestCard from "../components/Requests/RequestCard";
import RequestDetailModal from "../components/Requests/RequestDetailModal";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { ServiceRequest } from "../context/RequestsContext";

export default function AdminPanel() {
  const { userProfile } = useAuth();
  const { requests, loading } = useRequests();
  const [selectedRequest, setSelectedRequest] = useState<ServiceRequest | null>(null);
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [categoryFilter, setCategoryFilter] = useState<string>("all");

  if (userProfile?.role !== 'admin') {
    return (
      <AppLayout>
        <div className="text-center py-12">
          <i className="fas fa-exclamation-triangle text-6xl text-destructive mb-6"></i>
          <h3 className="text-lg font-semibold text-foreground mb-2">
            غير مصرح
          </h3>
          <p className="text-muted-foreground">
            ليس لديك صلاحية للوصول إلى لوحة الإدارة
          </p>
        </div>
      </AppLayout>
    );
  }

  const filteredRequests = requests.filter(request => {
    const categoryMatch = categoryFilter === "all" || request.category === categoryFilter;
    return categoryMatch;
  });

  const getStats = () => {
    const total = requests.length;
    const open = requests.filter(r => r.status === 'open').length;
    const accepted = requests.filter(r => r.status === 'accepted').length;
    const inProgress = requests.filter(r => r.status === 'in_progress').length;
    const completed = requests.filter(r => r.status === 'completed').length;
    const emergency = requests.filter(r => r.isEmergency).length;
    
    return { total, open, accepted, inProgress, completed, emergency };
  };

  const stats = getStats();

  if (loading) {
    return (
      <AppLayout>
        <div className="flex items-center justify-center h-64">
          <div className="text-center">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-4"></div>
            <p className="text-muted-foreground">جاري تحميل البيانات...</p>
          </div>
        </div>
      </AppLayout>
    );
  }

  return (
    <AppLayout>
      <div className="space-y-6" data-testid="admin-panel-page">
        {/* Header */}
        <div>
          <h1 className="text-2xl font-bold text-foreground mb-2">لوحة الإدارة</h1>
          <p className="text-muted-foreground">
            إدارة ومراقبة جميع طلبات الخدمة في النظام
          </p>
        </div>

        {/* Stats Overview */}
        <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-6 gap-4" data-testid="admin-stats">
          <Card>
            <CardContent className="p-4">
              <div className="text-center">
                <p className="text-2xl font-bold text-foreground" data-testid="stat-total">
                  {stats.total}
                </p>
                <p className="text-sm text-muted-foreground">إجمالي الطلبات</p>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="text-center">
                <p className="text-2xl font-bold text-blue-600" data-testid="stat-open">
                  {stats.open}
                </p>
                <p className="text-sm text-muted-foreground">متاح</p>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="text-center">
                <p className="text-2xl font-bold text-yellow-600" data-testid="stat-accepted">
                  {stats.accepted}
                </p>
                <p className="text-sm text-muted-foreground">مقبول</p>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="text-center">
                <p className="text-2xl font-bold text-orange-600" data-testid="stat-in-progress">
                  {stats.inProgress}
                </p>
                <p className="text-sm text-muted-foreground">قيد التنفيذ</p>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="text-center">
                <p className="text-2xl font-bold text-green-600" data-testid="stat-completed">
                  {stats.completed}
                </p>
                <p className="text-sm text-muted-foreground">مكتمل</p>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="text-center">
                <p className="text-2xl font-bold text-red-600" data-testid="stat-emergency">
                  {stats.emergency}
                </p>
                <p className="text-sm text-muted-foreground">عاجل</p>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Filters */}
        <Card>
          <CardContent className="p-4">
            <div className="flex flex-wrap gap-4">
              <div className="flex items-center space-x-2 space-x-reverse">
                <label className="text-sm font-medium">الفئة:</label>
                <Select value={categoryFilter} onValueChange={setCategoryFilter}>
                  <SelectTrigger className="w-48" data-testid="select-category-filter">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">جميع الفئات</SelectItem>
                    <SelectItem value="plumbing">سباكة</SelectItem>
                    <SelectItem value="electrical">كهرباء</SelectItem>
                    <SelectItem value="ac">تكييف</SelectItem>
                    <SelectItem value="painting">دهان</SelectItem>
                    <SelectItem value="cleaning">تنظيف</SelectItem>
                    <SelectItem value="carpentry">نجارة</SelectItem>
                    <SelectItem value="other">أخرى</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <span className="text-sm text-muted-foreground self-center">
                ({filteredRequests.length} من {requests.length} طلب)
              </span>
            </div>
          </CardContent>
        </Card>

        {/* System Status */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2 space-x-reverse">
                <i className="fas fa-exclamation-triangle text-red-500"></i>
                <span>الطلبات العاجلة</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              {requests.filter(r => r.isEmergency).length === 0 ? (
                <p className="text-muted-foreground text-center py-4">
                  لا توجد طلبات عاجلة
                </p>
              ) : (
                <div className="space-y-2">
                  {requests.filter(r => r.isEmergency).slice(0, 3).map(request => (
                    <div key={request.id} className="flex items-center justify-between p-2 bg-red-50 dark:bg-red-900/20 rounded">
                      <span className="text-sm font-medium">{request.title}</span>
                      <Badge className="bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200">
                        عاجل
                      </Badge>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2 space-x-reverse">
                <i className="fas fa-chart-line text-primary"></i>
                <span>إحصائيات سريعة</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex justify-between">
                  <span className="text-sm text-muted-foreground">معدل الإكمال</span>
                  <span className="font-medium">
                    {stats.total > 0 ? Math.round((stats.completed / stats.total) * 100) : 0}%
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-muted-foreground">الطلبات النشطة</span>
                  <span className="font-medium">
                    {stats.accepted + stats.inProgress}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-muted-foreground">في الانتظار</span>
                  <span className="font-medium">{stats.open}</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* All Requests */}
        <Card>
          <CardHeader>
            <CardTitle>جميع الطلبات</CardTitle>
          </CardHeader>
          <CardContent>
            {filteredRequests.length === 0 ? (
              <div className="text-center py-12" data-testid="no-requests">
                <i className="fas fa-search text-6xl text-muted-foreground mb-6"></i>
                <h3 className="text-lg font-semibold text-foreground mb-2">
                  لا توجد طلبات
                </h3>
                <p className="text-muted-foreground">
                  لا توجد طلبات تطابق الفلاتر المحددة
                </p>
              </div>
            ) : (
              <div className="space-y-4" data-testid="admin-requests-list">
                {filteredRequests.map((request) => (
                  <RequestCard
                    key={request.id}
                    request={request}
                    onViewDetails={setSelectedRequest}
                  />
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      <RequestDetailModal
        request={selectedRequest}
        isOpen={!!selectedRequest}
        onClose={() => setSelectedRequest(null)}
      />
    </AppLayout>
  );
}
