import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { useAuth } from "../context/AuthContext";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { MAIN_CATEGORIES, CITIES } from "../utils/constants";

export default function Home() {
  const [, setLocation] = useLocation();
  const { userProfile, loading } = useAuth();
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCity, setSelectedCity] = useState("");

  // إعادة توجيه المستخدم المسجل إلى لوحة التحكم
  useEffect(() => {
    if (!loading && userProfile) {
      setLocation("/dashboard");
    }
  }, [userProfile, loading, setLocation]);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-muted-foreground">جاري التحميل...</p>
        </div>
      </div>
    );
  }

  const handleSearch = () => {
    const query = searchQuery.trim();
    if (query) {
      const params = new URLSearchParams();
      params.set('q', query);
      setLocation(`/search?${params.toString()}`);
    }
  };

  const handleMainCategoryClick = (mainCategoryKey: string) => {
    setLocation(`/category/${mainCategoryKey}`);
  };

  // أيقونات الفئات الرئيسية
  const mainCategoryIcons: Record<string, string> = {
    real_estate: "fas fa-building",
    vehicles: "fas fa-car",
    services: "fas fa-tools",
    products: "fas fa-shopping-bag",
    jobs: "fas fa-briefcase"
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header Section */}
      <div className="bg-gradient-to-br from-primary/10 to-primary/5 py-12">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto text-center">
            <div className="flex items-center justify-center gap-3 mb-6">
              <div className="w-16 h-16 bg-primary rounded-xl flex items-center justify-center">
                <i className="fas fa-briefcase text-primary-foreground text-2xl"></i>
              </div>
              <h1 className="text-4xl font-bold text-foreground">أشغال</h1>
            </div>
            <p className="text-xl text-muted-foreground mb-8">
              منصة الخدمات والوظائف الأولى في سوريا
            </p>
            
            {/* شريط البحث الرئيسي */}
            <div className="max-w-3xl mx-auto mb-8 space-y-4">
              
              {/* شريط البحث */}
              <div className="flex gap-3">
                <Input
                  type="text"
                  placeholder="ابحث عن الخدمات أو الوظائف..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
                  className="text-lg py-3"
                  data-testid="search-input"
                />
                <Button 
                  onClick={handleSearch}
                  size="lg"
                  className="px-6"
                  data-testid="search-button"
                >
                  <i className="fas fa-search"></i>
                </Button>
              </div>
            </div>

            {/* أزرار الدخول للمستخدمين المسجلين */}
            {!userProfile && (
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button 
                  onClick={() => setLocation("/signup")}
                  className="px-8 py-2"
                  data-testid="button-signup"
                >
                  إنشاء حساب
                </Button>
                <Button 
                  variant="outline"
                  onClick={() => setLocation("/login")}
                  className="px-8 py-2"
                  data-testid="button-login"
                >
                  تسجيل الدخول
                </Button>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* أنواع الإعلانات */}
      <div className="py-12 bg-muted/30">
        <div className="container mx-auto px-4">
          <div className="max-w-6xl mx-auto">
            <div className="text-center mb-8">
              <h2 className="text-3xl font-bold text-foreground mb-4">
                انشر إعلانك
              </h2>
              <p className="text-lg text-muted-foreground">
                اطلب خدمة أو اعرض خدماتك ومهاراتك
              </p>
            </div>

            <div className="max-w-2xl mx-auto">
              {/* زر واحد لإنشاء إعلان */}
              <Card className="p-8 border-2 border-blue-200 bg-blue-50/50 hover:shadow-lg transition-shadow">
                <CardHeader className="text-center pb-6">
                  <div className="w-20 h-20 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <i className="fas fa-plus-circle text-blue-600 text-3xl"></i>
                  </div>
                  <CardTitle className="text-2xl text-blue-800 mb-2">
                    انشر إعلانك
                  </CardTitle>
                  <p className="text-blue-700">
                    اعرض أو اطلب أي شيء - خدمة، منتج، عقار، وظيفة
                  </p>
                </CardHeader>
                <CardContent>
                  <Button 
                    onClick={() => setLocation("/create-request")} 
                    className="w-full bg-blue-600 hover:bg-blue-700 h-12 text-lg font-medium"
                    data-testid="create-ad-button"
                  >
                    <i className="fas fa-plus mr-2"></i>
                    انشر إعلانك الآن
                  </Button>
                </CardContent>
              </Card>
            </div>
            
            {/* النسخة التجريبية */}
            <div className="max-w-2xl mx-auto mt-8">
              <Card className="p-4 border-2 border-orange-200 bg-orange-50/50">
                <CardContent className="text-center">
                  <p className="text-sm text-orange-700 mb-4 font-medium">
                    💡 جرب النموذج بدون تسجيل دخول
                  </p>
                  <Button 
                    onClick={() => setLocation("/demo-create-request")} 
                    variant="outline"
                    className="border-2 border-orange-300 text-orange-700 hover:bg-orange-100 font-medium"
                    data-testid="demo-request-button"
                  >
                    <i className="fas fa-flask mr-2"></i>
                    تجربة النموذج (تجريبي)
                  </Button>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>

      {/* شبكة الفئات - مثل مرجان */}
      <div className="py-12">
        <div className="container mx-auto px-4">
          <div className="max-w-7xl mx-auto">
            <div className="text-center mb-8">
              <h2 className="text-3xl font-bold text-foreground mb-4">
                تصفح حسب الفئة
              </h2>
              <p className="text-lg text-muted-foreground">
                اختر الفئة المناسبة لاحتياجاتك
              </p>
            </div>

            {/* شبكة الفئات الرئيسية مثل مرجان */}
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-6" data-testid="main-categories-grid">
              {Object.entries(MAIN_CATEGORIES).map(([key, label]) => (
                <Card 
                  key={key} 
                  className="cursor-pointer hover:shadow-lg hover:scale-105 transition-all duration-300 border-2 hover:border-primary/50 h-32"
                  onClick={() => handleMainCategoryClick(key)}
                  data-testid={`main-category-${key}`}
                >
                  <CardContent className="p-6 text-center h-full flex flex-col justify-center">
                    <div className="w-16 h-16 bg-gradient-to-br from-primary/20 to-primary/10 rounded-xl flex items-center justify-center mx-auto mb-3">
                      <i className={`${mainCategoryIcons[key]} text-primary text-2xl`}></i>
                    </div>
                    <h3 className="font-semibold text-base leading-tight">
                      {label}
                    </h3>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* قسم كيفية العمل */}
      <div className="py-16 bg-muted/30">
        <div className="container mx-auto px-4">
          <div className="max-w-6xl mx-auto text-center">
            <h2 className="text-3xl font-bold text-foreground mb-12">
              كيف تعمل أشغال؟
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="text-center">
                <div className="w-20 h-20 bg-primary rounded-full flex items-center justify-center mx-auto mb-4">
                  <span className="text-2xl font-bold text-primary-foreground">1</span>
                </div>
                <h3 className="text-xl font-semibold mb-3">اختر الفئة</h3>
                <p className="text-muted-foreground">
                  ابحث في الفئات المختلفة واختر الخدمة التي تحتاجها
                </p>
              </div>
              
              <div className="text-center">
                <div className="w-20 h-20 bg-primary rounded-full flex items-center justify-center mx-auto mb-4">
                  <span className="text-2xl font-bold text-primary-foreground">2</span>
                </div>
                <h3 className="text-xl font-semibold mb-3">تواصل مباشرة</h3>
                <p className="text-muted-foreground">
                  تواصل مع مقدمي الخدمة مباشرة واطلب عروض أسعار
                </p>
              </div>
              
              <div className="text-center">
                <div className="w-20 h-20 bg-primary rounded-full flex items-center justify-center mx-auto mb-4">
                  <span className="text-2xl font-bold text-primary-foreground">3</span>
                </div>
                <h3 className="text-xl font-semibold mb-3">اختر الأفضل</h3>
                <p className="text-muted-foreground">
                  قارن العروض واختر الأنسب لك حسب السعر والتقييمات
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
