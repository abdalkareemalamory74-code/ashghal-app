import { useState, useEffect } from "react";
import { useLocation, useSearch } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { 
  MAIN_CATEGORIES,
  SERVICE_CATEGORIES, 
  REAL_ESTATE_CATEGORIES,
  VEHICLE_CATEGORIES,
  PRODUCT_CATEGORIES,
  JOB_CATEGORIES,
  CITIES, 
  REQUEST_STATUSES, 
  POST_TYPES 
} from "../utils/constants";
import { useAuth } from "../context/AuthContext";
import AppLayout from "../components/Layout/AppLayout";

export default function Search() {
  const [, setLocation] = useLocation();
  const searchParams = useSearch();
  const { userProfile } = useAuth();
  
  // استخراج المعاملات من URL
  const urlParams = new URLSearchParams(searchParams);
  const initialQuery = urlParams.get('q') || '';
  const initialCity = urlParams.get('city') || 'all';
  const initialMainCategory = urlParams.get('mainCategory') || 'all';
  const initialCategory = urlParams.get('category') || 'all';
  const initialPostType = urlParams.get('type') || 'all';
  
  // حالات الفلترة
  const [searchQuery, setSearchQuery] = useState(initialQuery);
  const [selectedCity, setSelectedCity] = useState(initialCity);
  const [selectedMainCategory, setSelectedMainCategory] = useState(initialMainCategory);
  const [selectedCategory, setSelectedCategory] = useState(initialCategory);
  const [selectedPostType, setSelectedPostType] = useState(initialPostType);
  const [sortBy, setSortBy] = useState('recent');

  // الحصول على الفئات الفرعية حسب الفئة الرئيسية المحددة
  const getSubCategories = (mainCategory: string) => {
    switch(mainCategory) {
      case 'real_estate': return REAL_ESTATE_CATEGORIES;
      case 'vehicles': return VEHICLE_CATEGORIES;
      case 'services': return SERVICE_CATEGORIES;
      case 'products': return PRODUCT_CATEGORIES;
      case 'jobs': return JOB_CATEGORIES;
      default: return {};
    }
  };
  
  const subCategories = selectedMainCategory !== 'all' ? getSubCategories(selectedMainCategory) : {};

  // إعادة تعيين الفئة الفرعية عند تغيير الفئة الرئيسية
  useEffect(() => {
    setSelectedCategory('all');
  }, [selectedMainCategory]);

  // تحديث URL عند تغيير الفلاتر
  const updateFilters = () => {
    const params = new URLSearchParams();
    if (searchQuery.trim()) params.set('q', searchQuery.trim());
    if (selectedCity && selectedCity !== 'all') params.set('city', selectedCity);
    if (selectedMainCategory && selectedMainCategory !== 'all') params.set('mainCategory', selectedMainCategory);
    if (selectedCategory && selectedCategory !== 'all') params.set('category', selectedCategory);
    if (selectedPostType && selectedPostType !== 'all') params.set('type', selectedPostType);
    if (sortBy && sortBy !== 'recent') params.set('sort', sortBy);
    
    setLocation(`/search?${params.toString()}`);
  };

  // تعريف نوع البيانات
  interface SearchResult {
    id: string;
    title: string;
    description: string;
    mainCategory: string;
    category: string;
    city: string;
    postType: string;
    status: string;
    price?: string;
    budget?: string;
    salary?: string;
    createdAt: string;
    contactInfo: { phone: string; name: string };
    rating?: number;
    completedJobs?: number;
  }

  // جلب النتائج (mock data لحين إنشاء Backend)
  const { data: searchResults, isLoading } = useQuery<SearchResult[]>({
    queryKey: ['search', searchQuery, selectedCity, selectedMainCategory, selectedCategory, selectedPostType, sortBy],
    queryFn: (): Promise<SearchResult[]> => {
      // Mock search results - في المستقبل سيكون هذا API call حقيقي
      return new Promise<SearchResult[]>(resolve => {
        setTimeout(() => {
          const mockResults = [
            // خدمات
            {
              id: '1',
              title: 'كهربائي ماهر - إصلاح جميع الأعطال',
              description: 'كهربائي بخبرة 10 سنوات، إصلاح الأعطال الكهربائية، تركيب اللوحات والمفاتيح',
              mainCategory: 'services',
              category: 'electrical',
              city: 'damascus',
              postType: 'service_offer',
              status: 'open',
              price: '15000 ل.س/ساعة',
              createdAt: '2024-03-10',
              contactInfo: { phone: '0944123456', name: 'أحمد محمد' },
              rating: 4.8,
              completedJobs: 150
            },
            {
              id: '2', 
              title: 'مطلوب سباك للطوارئ - حلب',
              description: 'نحتاج سباك لإصلاح تسريب عاجل في المنزل، المنطقة: الأزهرية',
              mainCategory: 'services',
              category: 'plumbing',
              city: 'aleppo',
              postType: 'service_request',
              status: 'open',
              budget: '20000-30000 ل.س',
              createdAt: '2024-03-12',
              contactInfo: { phone: '0987654321', name: 'سارة أحمد' }
            },
            {
              id: '3',
              title: 'دهان منازل - أسعار منافسة',
              description: 'فريق دهان محترف، دهان داخلي وخارجي، ضمان على العمل لمدة سنة',
              mainCategory: 'services',
              category: 'painting',
              city: 'damascus',
              postType: 'service_offer',
              status: 'open',
              price: '2500 ل.س/م²',
              createdAt: '2024-03-11',
              contactInfo: { phone: '0933111222', name: 'محمد علي' },
              rating: 4.5,
              completedJobs: 85
            },
            // عقارات
            {
              id: '4',
              title: 'شقة للبيع - دمشق الجديدة',
              description: 'شقة 3 غرف، 2 حمام، مساحة 120 متر، الطابق الثالث، مصعد',
              mainCategory: 'real_estate',
              category: 'apartments',
              city: 'damascus',
              postType: 'real_estate_sale',
              status: 'open',
              price: '45000000 ل.س',
              createdAt: '2024-03-09',
              contactInfo: { phone: '0944555666', name: 'أحمد العقاري' }
            },
            {
              id: '5',
              title: 'منزل للإيجار - حي الزهراء',
              description: 'منزل مستقل، 4 غرف، حديقة صغيرة، موقف سيارة',
              mainCategory: 'real_estate',
              category: 'houses',
              city: 'aleppo',
              postType: 'real_estate_rent',
              status: 'open',
              price: '180000 ل.س/شهر',
              createdAt: '2024-03-08',
              contactInfo: { phone: '0987777888', name: 'سامر العقار' }
            },
            // مركبات
            {
              id: '6',
              title: 'كيا سيراتو 2018 للبيع',
              description: 'سيارة نظيفة جداً، كيلومتر قليل، فحص كامل',
              mainCategory: 'vehicles',
              category: 'cars',
              city: 'damascus',
              postType: 'vehicle_sale',
              status: 'open',
              price: '12500000 ل.س',
              createdAt: '2024-03-08',
              contactInfo: { phone: '0933777888', name: 'محمد السيارات' }
            },
            // وظائف
            {
              id: '7',
              title: 'مطلوب مهندس برمجيات - دوام كامل',
              description: 'شركة تقنية تبحث عن مطور React.js خبرة 3+ سنوات',
              mainCategory: 'jobs',
              category: 'technology',
              city: 'damascus',
              postType: 'job_offer',
              status: 'open',
              salary: '1500000 ل.س/شهر',
              createdAt: '2024-03-07',
              contactInfo: { phone: '0911999000', name: 'شركة التقنية الحديثة' }
            },
            {
              id: '8',
              title: 'مدرس رياضيات يبحث عن وظيفة',
              description: 'مدرس رياضيات خبرة 10 سنوات، إجازة في الرياضيات',
              mainCategory: 'jobs',
              category: 'education',
              city: 'aleppo',
              postType: 'job_request',
              status: 'open',
              createdAt: '2024-03-06',
              contactInfo: { phone: '0987123456', name: 'أحمد المدرس' }
            },
            // منتجات
            {
              id: '9',
              title: 'لابتوب Dell للبيع - حالة ممتازة',
              description: 'لابتوب Dell Inspiron، معالج i7، رام 16GB، استخدام شخصي',
              mainCategory: 'products',
              category: 'electronics',
              city: 'aleppo',
              postType: 'product_sale',
              status: 'open',
              price: '850000 ل.س',
              createdAt: '2024-03-06',
              contactInfo: { phone: '0987111222', name: 'سامر التقنية' }
            },
            {
              id: '10',
              title: 'طقم أثاث غرفة جلوس للبيع',
              description: 'طقم أثاث كامل، حالة جيدة، 3+2+1، لون بيج',
              mainCategory: 'products',
              category: 'furniture',
              city: 'damascus',
              postType: 'product_sale',
              status: 'open',
              price: '750000 ل.س',
              createdAt: '2024-03-05',
              contactInfo: { phone: '0944333555', name: 'خالد الأثاث' }
            }
          ];
          
          // تطبيق الفلاتر على البيانات الوهمية
          let filtered = mockResults.filter(item => {
            const matchesQuery = !searchQuery || 
              item.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
              item.description.toLowerCase().includes(searchQuery.toLowerCase());
            
            const matchesCity = selectedCity === 'all' || item.city === selectedCity;
            const matchesMainCategory = selectedMainCategory === 'all' || item.mainCategory === selectedMainCategory;
            const matchesCategory = selectedCategory === 'all' || item.category === selectedCategory;
            const matchesPostType = selectedPostType === 'all' || item.postType === selectedPostType;
            
            return matchesQuery && matchesCity && matchesMainCategory && matchesCategory && matchesPostType;
          });
          
          // ترتيب النتائج
          if (sortBy === 'price_low') {
            filtered.sort((a, b) => parseFloat(a.price?.replace(/[^\d]/g, '') || '0') - parseFloat(b.price?.replace(/[^\d]/g, '') || '0'));
          } else if (sortBy === 'price_high') {
            filtered.sort((a, b) => parseFloat(b.price?.replace(/[^\d]/g, '') || '0') - parseFloat(a.price?.replace(/[^\d]/g, '') || '0'));
          } else if (sortBy === 'rating') {
            filtered.sort((a, b) => (b.rating || 0) - (a.rating || 0));
          } else {
            // recent
            filtered.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
          }
          
          resolve(filtered);
        }, 300);
      });
    }
  });

  // أيقونات الفئات الرئيسية
  const mainCategoryIcons: Record<string, string> = {
    real_estate: "fas fa-building",
    vehicles: "fas fa-car",
    services: "fas fa-tools",
    products: "fas fa-shopping-bag",
    jobs: "fas fa-briefcase"
  };

  // أيقونات الفئات الفرعية
  const categoryIcons: Record<string, string> = {
    electrical: "fas fa-bolt",
    plumbing: "fas fa-wrench", 
    painting: "fas fa-paint-roller",
    construction: "fas fa-hammer",
    carpentry: "fas fa-cut",
    aluminum: "fas fa-window-maximize",
    ac_cooling: "fas fa-snowflake",
    blacksmith: "fas fa-fire",
    well_drilling: "fas fa-tint",
    maintenance: "fas fa-home",
    transport: "fas fa-truck",
    cleaning: "fas fa-broom",
    gardening: "fas fa-leaf",
    security: "fas fa-shield-alt",
    catering: "fas fa-utensils",
    education: "fas fa-book",
    technology: "fas fa-laptop",
    health: "fas fa-heart",
    legal: "fas fa-gavel",
    // Real Estate
    apartments: "fas fa-building",
    houses: "fas fa-home",
    villas: "fas fa-home",
    offices: "fas fa-building",
    shops: "fas fa-store",
    warehouses: "fas fa-warehouse",
    lands: "fas fa-map",
    farms: "fas fa-seedling",
    // Vehicles
    cars: "fas fa-car",
    motorcycles: "fas fa-motorcycle",
    trucks: "fas fa-truck",
    buses: "fas fa-bus",
    boats: "fas fa-ship",
    bicycles: "fas fa-bicycle",
    spare_parts: "fas fa-cog",
    accessories: "fas fa-tools",
    // Products
    electronics: "fas fa-laptop",
    appliances: "fas fa-tv",
    furniture: "fas fa-chair",
    clothing: "fas fa-tshirt",
    books: "fas fa-book",
    sports: "fas fa-dumbbell",
    toys: "fas fa-gamepad",
    jewelry: "fas fa-gem",
    cosmetics: "fas fa-mirror",
    food: "fas fa-utensils",
    tools: "fas fa-wrench",
    art: "fas fa-paint-brush",
    medical: "fas fa-stethoscope",
    baby: "fas fa-baby",
    pets: "fas fa-paw",
    garden: "fas fa-leaf",
    // Jobs
    engineering: "fas fa-cogs",
    medicine: "fas fa-user-md",
    finance: "fas fa-dollar-sign",
    marketing: "fas fa-bullhorn",
    management: "fas fa-users",
    arts: "fas fa-palette",
    media: "fas fa-newspaper",
    hospitality: "fas fa-concierge-bell",
    manufacturing: "fas fa-industry",
    agriculture: "fas fa-tractor",
    food_service: "fas fa-hamburger",
    other: "fas fa-ellipsis-h"
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('ar-SY', {
      year: 'numeric',
      month: 'long', 
      day: 'numeric'
    });
  };

  const getPostTypeColor = (type: string) => {
    switch(type) {
      case 'service_offer': return 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200';
      case 'job_offer': return 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200';
      case 'service_request': return 'bg-orange-100 text-orange-800 dark:bg-orange-900 dark:text-orange-200';
      case 'job_request': return 'bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-200';
      case 'real_estate_sale': return 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200';
      case 'real_estate_rent': return 'bg-teal-100 text-teal-800 dark:bg-teal-900 dark:text-teal-200';
      case 'vehicle_sale': return 'bg-indigo-100 text-indigo-800 dark:bg-indigo-900 dark:text-indigo-200';
      case 'product_sale': return 'bg-pink-100 text-pink-800 dark:bg-pink-900 dark:text-pink-200';
      default: return 'bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-200';
    }
  };

  return (
    <AppLayout>
      <div className="container mx-auto px-4 py-8">
        {/* عنوان الصفحة */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-foreground mb-2">
            البحث الشامل
          </h1>
          <p className="text-muted-foreground">
            ابحث في جميع الفئات: خدمات، عقارات، مركبات، منتجات ووظائف
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* الفلاتر الجانبية */}
          <div className="lg:col-span-1">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg font-semibold">
                  <i className="fas fa-filter mr-2"></i>
                  فلترة النتائج
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* البحث بالنص */}
                <div>
                  <Label className="text-sm font-medium mb-2 block">البحث</Label>
                  <Input
                    placeholder="ابحث بالكلمات المفتاحية..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    data-testid="filter-search-input"
                  />
                </div>

                {/* الفئة الرئيسية */}
                <div>
                  <Label className="text-sm font-medium mb-2 block">الفئة الرئيسية</Label>
                  <Select value={selectedMainCategory} onValueChange={setSelectedMainCategory}>
                    <SelectTrigger data-testid="filter-main-category-select">
                      <SelectValue placeholder="جميع الفئات" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">جميع الفئات الرئيسية</SelectItem>
                      {Object.entries(MAIN_CATEGORIES).map(([key, label]) => (
                        <SelectItem key={key} value={key}>{label}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* الفئة الفرعية */}
                {Object.keys(subCategories).length > 0 && (
                  <div>
                    <Label className="text-sm font-medium mb-2 block">الفئة الفرعية</Label>
                    <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                      <SelectTrigger data-testid="filter-category-select">
                        <SelectValue placeholder="جميع الفئات الفرعية" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">جميع الفئات الفرعية</SelectItem>
                        {Object.entries(subCategories).map(([key, label]) => (
                          <SelectItem key={key} value={key}>{String(label)}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                )}

                {/* المدينة */}
                <div>
                  <Label className="text-sm font-medium mb-2 block">المدينة</Label>
                  <Select value={selectedCity} onValueChange={setSelectedCity}>
                    <SelectTrigger data-testid="filter-city-select">
                      <SelectValue placeholder="جميع المدن" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">جميع المدن</SelectItem>
                      {Object.entries(CITIES).map(([key, label]) => (
                        <SelectItem key={key} value={key}>
                          {label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* نوع الإعلان */}
                <div>
                  <Label className="text-sm font-medium mb-2 block">نوع الإعلان</Label>
                  <Select value={selectedPostType} onValueChange={setSelectedPostType}>
                    <SelectTrigger data-testid="filter-post-type-select">
                      <SelectValue placeholder="جميع الأنواع" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">جميع الأنواع</SelectItem>
                      {Object.entries(POST_TYPES).map(([key, label]) => (
                        <SelectItem key={key} value={key}>
                          {label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>


                {/* الترتيب */}
                <div>
                  <Label className="text-sm font-medium mb-2 block">ترتيب حسب</Label>
                  <Select value={sortBy} onValueChange={setSortBy}>
                    <SelectTrigger data-testid="filter-sort-select">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="recent">الأحدث</SelectItem>
                      <SelectItem value="price_low">السعر (من الأقل)</SelectItem>
                      <SelectItem value="price_high">السعر (من الأعلى)</SelectItem>
                      <SelectItem value="rating">التقييم</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <Button 
                  onClick={updateFilters}
                  className="w-full"
                  data-testid="apply-filters-button"
                >
                  <i className="fas fa-search mr-2"></i>
                  تطبيق الفلاتر
                </Button>
              </CardContent>
            </Card>
          </div>

          {/* النتائج */}
          <div className="lg:col-span-3">
            {isLoading ? (
              <div className="text-center py-12">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-4"></div>
                <p className="text-muted-foreground">جاري البحث...</p>
              </div>
            ) : (
              <div className="space-y-6">
                {/* عدد النتائج */}
                <div className="flex items-center justify-between">
                  <h2 className="text-xl font-semibold">
                    النتائج ({searchResults?.length || 0})
                  </h2>
                  {searchQuery && (
                    <Badge variant="outline">
                      البحث: "{searchQuery}"
                    </Badge>
                  )}
                </div>

                {/* عرض النتائج */}
                {searchResults && searchResults.length > 0 ? (
                  <div className="space-y-4">
                    {searchResults.map((result: SearchResult) => (
                      <Card key={result.id} className="hover:shadow-md transition-shadow" data-testid={`search-result-${result.id}`}>
                        <CardContent className="p-6">
                          <div className="flex items-start justify-between mb-4">
                            <div className="flex items-center gap-3">
                              <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                                <i className={`${categoryIcons[result.category] || mainCategoryIcons[result.mainCategory]} text-primary text-xl`}></i>
                              </div>
                              <div>
                                <h3 className="font-semibold text-lg mb-1" data-testid={`result-title-${result.id}`}>
                                  {result.title}
                                </h3>
                                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                                  <span>{MAIN_CATEGORIES[result.mainCategory as keyof typeof MAIN_CATEGORIES]}</span>
                                  <span>•</span>
                                  <span>{CITIES[result.city as keyof typeof CITIES]}</span>
                                  <span>•</span>
                                  <span>{formatDate(result.createdAt)}</span>
                                </div>
                              </div>
                            </div>
                            <div className="flex flex-col items-end gap-2">
                              <Badge className={getPostTypeColor(result.postType)} data-testid={`result-type-${result.id}`}>
                                {POST_TYPES[result.postType as keyof typeof POST_TYPES]}
                              </Badge>
                              {result.rating && (
                                <div className="flex items-center gap-1">
                                  <i className="fas fa-star text-yellow-500 text-sm"></i>
                                  <span className="text-sm font-medium">{result.rating}</span>
                                  <span className="text-xs text-muted-foreground">
                                    ({result.completedJobs} عمل)
                                  </span>
                                </div>
                              )}
                            </div>
                          </div>

                          <p className="text-muted-foreground mb-4 line-clamp-2" data-testid={`result-description-${result.id}`}>
                            {result.description}
                          </p>

                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-4">
                              {result.price && (
                                <span className="font-semibold text-primary" data-testid={`result-price-${result.id}`}>
                                  {result.price}
                                </span>
                              )}
                              {result.budget && (
                                <span className="font-semibold text-primary" data-testid={`result-budget-${result.id}`}>
                                  {result.budget}
                                </span>
                              )}
                              {result.salary && (
                                <span className="font-semibold text-primary" data-testid={`result-salary-${result.id}`}>
                                  {result.salary}
                                </span>
                              )}
                            </div>
                            <div className="flex items-center gap-2">
                              <Button variant="outline" size="sm" data-testid={`contact-button-${result.id}`}>
                                <i className="fas fa-phone mr-2"></i>
                                تواصل
                              </Button>
                              <Button size="sm" data-testid={`details-button-${result.id}`}>
                                عرض التفاصيل
                              </Button>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-12">
                    <div className="w-20 h-20 bg-muted rounded-full flex items-center justify-center mx-auto mb-4">
                      <i className="fas fa-search text-muted-foreground text-2xl"></i>
                    </div>
                    <h3 className="text-lg font-semibold mb-2">لا توجد نتائج</h3>
                    <p className="text-muted-foreground mb-4">
                      لم نجد أي نتائج تطابق معايير البحث المحددة.
                    </p>
                    <div className="flex gap-2 justify-center">
                      <Button 
                        variant="outline"
                        onClick={() => {
                          setSearchQuery('');
                          setSelectedCity('all');
                          setSelectedMainCategory('all');
                          setSelectedCategory('all');
                          setSelectedPostType('all');
                        }}
                        data-testid="clear-filters-button"
                      >
                        إزالة الفلاتر
                      </Button>
                      <Button 
                        onClick={() => setLocation('/create-request')}
                        data-testid="create-post-button"
                      >
                        أنشئ إعلان جديد
                      </Button>
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      </div>
    </AppLayout>
  );
}