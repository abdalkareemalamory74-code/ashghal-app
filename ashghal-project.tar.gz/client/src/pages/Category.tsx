import { useEffect } from "react";
import { useLocation, useParams, Link } from "wouter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ArrowRight, ChevronLeft } from "lucide-react";
import { 
  MAIN_CATEGORIES, 
  SERVICE_CATEGORIES, 
  REAL_ESTATE_CATEGORIES, 
  VEHICLE_CATEGORIES, 
  PRODUCT_CATEGORIES, 
  JOB_CATEGORIES
} from "../utils/constants";
import { useAuth } from "../context/AuthContext";
import AppLayout from "../components/Layout/AppLayout";

interface CategoryParams {
  category: string;
}

export default function Category() {
  const params = useParams<CategoryParams>();
  const [, setLocation] = useLocation();
  const { userProfile } = useAuth();
  
  const mainCategoryKey = params.category;
  const mainCategoryName = MAIN_CATEGORIES[mainCategoryKey as keyof typeof MAIN_CATEGORIES];
  
  // الحصول على الفئات الفرعية حسب الفئة الرئيسية
  const getSubCategories = (mainCategory: string): Record<string, string> => {
    switch(mainCategory) {
      case 'real_estate': return REAL_ESTATE_CATEGORIES;
      case 'vehicles': return VEHICLE_CATEGORIES;
      case 'services': return SERVICE_CATEGORIES;
      case 'products': return PRODUCT_CATEGORIES;
      case 'jobs': return JOB_CATEGORIES;
      default: return {};
    }
  };
  
  const subCategories = getSubCategories(mainCategoryKey || '');

  // التحقق من صحة الفئة
  useEffect(() => {
    if (!mainCategoryKey || !mainCategoryName) {
      setLocation('/');
    }
  }, [mainCategoryKey, mainCategoryName, setLocation]);

  // أيقونات الفئات الرئيسية
  const mainCategoryIcons: Record<string, string> = {
    real_estate: "fas fa-building",
    vehicles: "fas fa-car",
    services: "fas fa-tools",
    products: "fas fa-shopping-bag",
    jobs: "fas fa-briefcase"
  };

  // أيقونات الفئات الفرعية
  const subCategoryIcons: Record<string, string> = {
    // الخدمات
    electrical: "fas fa-bolt",
    plumbing: "fas fa-wrench", 
    painting: "fas fa-paint-roller",
    construction: "fas fa-hard-hat",
    carpentry: "fas fa-hammer",
    aluminum: "fas fa-window-maximize",
    ac_cooling: "fas fa-snowflake",
    blacksmith: "fas fa-fire",
    well_drilling: "fas fa-tint",
    maintenance: "fas fa-screwdriver",
    transport: "fas fa-truck",
    cleaning: "fas fa-broom",
    gardening: "fas fa-seedling",
    security: "fas fa-shield-alt",
    catering: "fas fa-utensils",
    education: "fas fa-chalkboard-teacher",
    technology: "fas fa-laptop-code",
    health: "fas fa-stethoscope",
    legal: "fas fa-balance-scale",
    
    // العقارات
    apartments: "fas fa-building",
    houses: "fas fa-home",
    villas: "fas fa-house-user",
    offices: "fas fa-briefcase",
    shops: "fas fa-store",
    warehouses: "fas fa-warehouse",
    lands: "fas fa-map",
    farms: "fas fa-tractor",
    
    // المركبات
    cars: "fas fa-car",
    motorcycles: "fas fa-motorcycle",
    trucks: "fas fa-truck",
    buses: "fas fa-bus",
    boats: "fas fa-ship",
    bicycles: "fas fa-bicycle",
    spare_parts: "fas fa-cog",
    accessories: "fas fa-tools",
    
    // المنتجات
    electronics: "fas fa-mobile-alt",
    appliances: "fas fa-tv",
    furniture: "fas fa-couch",
    clothing: "fas fa-tshirt",
    books: "fas fa-book",
    sports: "fas fa-football-ball",
    toys: "fas fa-gamepad",
    jewelry: "fas fa-gem",
    cosmetics: "fas fa-spray-can",
    food: "fas fa-apple-alt",
    tools: "fas fa-toolbox",
    art: "fas fa-palette",
    medical: "fas fa-first-aid",
    baby: "fas fa-baby",
    pets: "fas fa-paw",
    garden: "fas fa-leaf",
    
    // الوظائف
    engineering: "fas fa-drafting-compass",
    medicine: "fas fa-user-md",
    finance: "fas fa-chart-line",
    marketing: "fas fa-bullhorn",
    management: "fas fa-users",
    arts: "fas fa-paint-brush",
    media: "fas fa-newspaper",
    hospitality: "fas fa-concierge-bell",
    transportation: "fas fa-shipping-fast",
    retail: "fas fa-shopping-cart",
    manufacturing: "fas fa-industry",
    agriculture: "fas fa-wheat",
    food_service: "fas fa-hamburger",
    
    other: "fas fa-ellipsis-h"
  };

  if (!mainCategoryKey || !mainCategoryName) {
    return null;
  }

  return (
    <AppLayout>
      <div className="min-h-screen bg-background" dir="rtl">
        <div className="container max-w-7xl mx-auto px-4 py-8">
          {/* شريط التنقل */}
          <div className="flex items-center gap-4 mb-8" data-testid="breadcrumb-nav">
            <Button 
              variant="outline" 
              size="sm"
              onClick={() => setLocation('/')}
              className="flex items-center gap-2"
              data-testid="button-back-home"
            >
              <ChevronLeft className="h-4 w-4" />
              الرئيسية
            </Button>
            <ArrowRight className="h-4 w-4 text-muted-foreground" />
            <span className="text-muted-foreground" data-testid="text-current-category">
              {mainCategoryName}
            </span>
          </div>

          {/* العنوان الرئيسي */}
          <div className="text-center mb-12">
            <div className="flex items-center justify-center gap-4 mb-4">
              <div className="w-16 h-16 bg-primary/10 rounded-2xl flex items-center justify-center">
                <i className={`${mainCategoryIcons[mainCategoryKey]} text-primary text-3xl`}></i>
              </div>
            </div>
            <h1 className="text-4xl font-bold text-foreground mb-3" data-testid="category-title">
              {mainCategoryName}
            </h1>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              اختر الفئة الفرعية للبحث في الإعلانات المناسبة لك
            </p>
          </div>

          {/* شبكة الفئات الفرعية */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {Object.entries(subCategories).map(([subCategoryKey, subCategoryName]) => (
              <Card 
                key={subCategoryKey} 
                className="group cursor-pointer hover:shadow-lg transition-all duration-200 hover:-translate-y-1 border-2 hover:border-primary/20"
                data-testid={`subcategory-card-${subCategoryKey}`}
              >
                <Link href={`/category/${mainCategoryKey}/${subCategoryKey}`}>
                  <CardContent className="p-6 text-center">
                    <div className="w-16 h-16 bg-primary/10 rounded-xl flex items-center justify-center mx-auto mb-4 group-hover:bg-primary/20 transition-colors">
                      <i className={`${subCategoryIcons[subCategoryKey] || 'fas fa-folder'} text-primary text-2xl`}></i>
                    </div>
                    <h3 className="text-lg font-semibold text-foreground mb-2 group-hover:text-primary transition-colors" data-testid={`subcategory-name-${subCategoryKey}`}>
                      {subCategoryName}
                    </h3>
                    <div className="flex items-center justify-center text-sm text-muted-foreground group-hover:text-primary/70 transition-colors">
                      تصفح الإعلانات
                      <ArrowRight className="h-4 w-4 mr-2 group-hover:translate-x-1 transition-transform" />
                    </div>
                  </CardContent>
                </Link>
              </Card>
            ))}
          </div>

          {/* رسالة إذا لم توجد فئات فرعية */}
          {Object.keys(subCategories).length === 0 && (
            <div className="text-center py-16">
              <div className="w-24 h-24 bg-muted rounded-full flex items-center justify-center mx-auto mb-6">
                <i className="fas fa-folder-open text-muted-foreground text-3xl"></i>
              </div>
              <h3 className="text-xl font-semibold text-muted-foreground mb-2">
                لا توجد فئات فرعية متاحة
              </h3>
              <p className="text-muted-foreground">
                هذا القسم قيد التطوير، سيتم إضافة الفئات قريباً
              </p>
            </div>
          )}
        </div>
      </div>
    </AppLayout>
  );
}