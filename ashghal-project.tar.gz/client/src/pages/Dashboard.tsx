import { useState } from "react";
import { Link } from "wouter";
import { useAuth } from "../context/AuthContext";
import { useRequests } from "../context/RequestsContext";
import AppLayout from "../components/Layout/AppLayout";
import RequestCard from "../components/Requests/RequestCard";
import RequestDetailModal from "../components/Requests/RequestDetailModal";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ServiceRequest } from "../context/RequestsContext";

export default function Dashboard() {
  const { userProfile } = useAuth();
  const { requests, myRequests, loading } = useRequests();
  const [selectedRequest, setSelectedRequest] = useState<ServiceRequest | null>(null);

  if (!userProfile) return null;

  const getStats = () => {
    if (userProfile.role === 'user') {
      const total = myRequests.length;
      const inProgress = myRequests.filter(r => r.status === 'in_progress').length;
      const completed = myRequests.filter(r => r.status === 'completed').length;
      const open = myRequests.filter(r => r.status === 'open').length;
      
      return { total, inProgress, completed, open };
    } else if (userProfile.role === 'worker') {
      const myJobs = requests.filter(r => r.workerId === userProfile.uid);
      const available = requests.filter(r => r.status === 'open').length;
      const inProgress = myJobs.filter(r => r.status === 'in_progress').length;
      const completed = myJobs.filter(r => r.status === 'completed').length;
      
      return { total: myJobs.length, available, inProgress, completed };
    } else {
      const total = requests.length;
      const inProgress = requests.filter(r => r.status === 'in_progress').length;
      const completed = requests.filter(r => r.status === 'completed').length;
      const open = requests.filter(r => r.status === 'open').length;
      
      return { total, inProgress, completed, open };
    }
  };

  const stats = getStats();
  
  const recentRequests = userProfile.role === 'user' 
    ? myRequests.slice(0, 3)
    : requests.slice(0, 3);

  if (loading) {
    return (
      <AppLayout>
        <div className="flex items-center justify-center h-64">
          <div className="text-center">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-4"></div>
            <p className="text-muted-foreground">جاري تحميل البيانات...</p>
          </div>
        </div>
      </AppLayout>
    );
  }

  return (
    <AppLayout>
      <div className="space-y-6" data-testid="dashboard">
        {/* Welcome Message */}
        <div className="bg-gradient-to-l from-primary/10 to-primary/5 rounded-lg p-6">
          <h1 className="text-2xl font-bold text-foreground mb-2" data-testid="welcome-message">
            مرحباً، {userProfile.name}
          </h1>
          <p className="text-muted-foreground">
            {userProfile.role === 'user' && 'إدارة طلبات الخدمة الخاصة بك'}
            {userProfile.role === 'worker' && 'اعرض الطلبات المتاحة وإدارة أعمالك'}
            {userProfile.role === 'admin' && 'لوحة إدارة النظام والمستخدمين'}
          </p>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6" data-testid="stats-cards">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">
                    {userProfile.role === 'user' ? 'إجمالي الطلبات' :
                     userProfile.role === 'worker' ? 'أعمالي' : 'إجمالي الطلبات'}
                  </p>
                  <p className="text-2xl font-bold" data-testid="stat-total">
                    {stats.total}
                  </p>
                </div>
                <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                  <i className="fas fa-clipboard-list text-primary text-xl"></i>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">
                    {userProfile.role === 'worker' ? 'متاحة' : 'قيد التنفيذ'}
                  </p>
                  <p className="text-2xl font-bold" data-testid="stat-progress">
                    {userProfile.role === 'worker' ? stats.available || 0 : stats.inProgress}
                  </p>
                </div>
                <div className="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center">
                  <i className="fas fa-clock text-orange-600 text-xl"></i>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">مكتملة</p>
                  <p className="text-2xl font-bold" data-testid="stat-completed">
                    {stats.completed}
                  </p>
                </div>
                <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                  <i className="fas fa-check-circle text-green-600 text-xl"></i>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">التقييم</p>
                  <p className="text-2xl font-bold" data-testid="stat-rating">4.8</p>
                </div>
                <div className="w-12 h-12 bg-yellow-100 rounded-lg flex items-center justify-center">
                  <i className="fas fa-star text-yellow-600 text-xl"></i>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Quick Actions */}
        <Card>
          <CardHeader>
            <CardTitle>إجراءات سريعة</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {userProfile.role === 'user' && (
                <Link href="/create-request">
                  <a className="block">
                    <div className="p-4 rounded-lg border-2 border-dashed border-border hover:border-primary hover:bg-primary/5 transition-colors text-center group" data-testid="quick-action-create">
                      <i className="fas fa-plus text-2xl text-muted-foreground group-hover:text-primary mb-2 block"></i>
                      <p className="font-medium">طلب خدمة جديد</p>
                      <p className="text-sm text-muted-foreground">أضف طلب خدمة جديد</p>
                    </div>
                  </a>
                </Link>
              )}
              
              <Link href={userProfile.role === 'user' ? "/my-requests" : userProfile.role === 'worker' ? "/worker-dashboard" : "/admin-panel"}>
                <a className="block">
                  <div className="p-4 rounded-lg border-2 border-dashed border-border hover:border-primary hover:bg-primary/5 transition-colors text-center group" data-testid="quick-action-view">
                    <i className="fas fa-list text-2xl text-muted-foreground group-hover:text-primary mb-2 block"></i>
                    <p className="font-medium">
                      {userProfile.role === 'user' ? 'عرض الطلبات' :
                       userProfile.role === 'worker' ? 'الطلبات المتاحة' : 'لوحة الإدارة'}
                    </p>
                    <p className="text-sm text-muted-foreground">
                      {userProfile.role === 'user' ? 'راجع جميع طلباتك' :
                       userProfile.role === 'worker' ? 'اعرض الطلبات المتاحة' : 'إدارة النظام'}
                    </p>
                  </div>
                </a>
              </Link>
              
              <div className="p-4 rounded-lg border-2 border-dashed border-border hover:border-primary hover:bg-primary/5 transition-colors text-center group cursor-pointer" data-testid="quick-action-support">
                <i className="fas fa-headset text-2xl text-muted-foreground group-hover:text-primary mb-2 block"></i>
                <p className="font-medium">الدعم الفني</p>
                <p className="text-sm text-muted-foreground">تحدث مع فريق الدعم</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Recent Requests */}
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle>
                {userProfile.role === 'user' ? 'طلباتي الأخيرة' : 'الطلبات الأخيرة'}
              </CardTitle>
              <Button variant="outline" size="sm" asChild>
                <Link href={userProfile.role === 'user' ? "/my-requests" : userProfile.role === 'worker' ? "/worker-dashboard" : "/admin-panel"}>
                  عرض الكل
                </Link>
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            {recentRequests.length === 0 ? (
              <div className="text-center py-8" data-testid="no-requests">
                <i className="fas fa-clipboard-list text-4xl text-muted-foreground mb-4"></i>
                <p className="text-muted-foreground">
                  {userProfile.role === 'user' ? 'لا توجد طلبات بعد' : 'لا توجد طلبات'}
                </p>
                {userProfile.role === 'user' && (
                  <Button className="mt-4" asChild>
                    <Link href="/create-request">إنشاء طلب جديد</Link>
                  </Button>
                )}
              </div>
            ) : (
              <div className="space-y-4" data-testid="recent-requests">
                {recentRequests.map((request) => (
                  <RequestCard
                    key={request.id}
                    request={request}
                    onViewDetails={setSelectedRequest}
                  />
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      <RequestDetailModal
        request={selectedRequest}
        isOpen={!!selectedRequest}
        onClose={() => setSelectedRequest(null)}
      />
    </AppLayout>
  );
}
