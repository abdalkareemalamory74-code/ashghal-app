import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";
import { useLocation } from "wouter";
import DemoRequestForm from "../components/Requests/DemoRequestForm";

export default function DemoCreateRequest() {
  const [, setLocation] = useLocation();

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="bg-gradient-to-br from-primary/10 to-primary/5 py-8">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 bg-primary rounded-lg flex items-center justify-center">
                  <i className="fas fa-briefcase text-primary-foreground text-xl"></i>
                </div>
                <div>
                  <h1 className="text-2xl font-bold text-foreground">أشغال - تجريبي</h1>
                  <p className="text-sm text-muted-foreground">جرب النموذج بدون تسجيل</p>
                </div>
              </div>
              <Button 
                variant="outline" 
                onClick={() => setLocation("/")}
                data-testid="button-back-home"
              >
                <i className="fas fa-home mr-2"></i>
                العودة للرئيسية
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto" data-testid="demo-create-request-page">
          
          {/* Information Card */}
          <Card className="mb-6 border-amber-200 bg-amber-50">
            <CardHeader className="pb-4">
              <CardTitle className="text-lg text-amber-800 flex items-center gap-2">
                <div className="w-6 h-6 rounded-full bg-amber-500 flex items-center justify-center">
                  <span className="text-white text-sm">!</span>
                </div>
                نسخة تجريبية من صفحة طلب الخدمة
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3 text-amber-800">
              <p>
                <strong>هذه نسخة تجريبية</strong> تتيح لك تجربة النموذج دون الحاجة لإنشاء حساب.
              </p>
              <div className="space-y-2 text-sm">
                <p><span className="font-medium">✅ متاح:</span> ملء النموذج، اختيار الفئات، تحديد المواعيد</p>
                <p><span className="font-medium">⚠️ غير متاح:</span> رفع الصور، حفظ البيانات الفعلي، التواصل مع المقاولين</p>
              </div>
              <div className="pt-2 border-t border-amber-200">
                <p className="text-sm">
                  للاستفادة من جميع الميزات، يرجى 
                  <Button 
                    variant="link" 
                    className="px-1 h-auto text-amber-800 underline font-medium"
                    onClick={() => setLocation("/signup")}
                    data-testid="link-signup"
                  >
                    إنشاء حساب جديد
                  </Button>
                  أو 
                  <Button 
                    variant="link" 
                    className="px-1 h-auto text-amber-800 underline font-medium"
                    onClick={() => setLocation("/login")}
                    data-testid="link-login"
                  >
                    تسجيل الدخول
                  </Button>
                </p>
              </div>
            </CardContent>
          </Card>

          {/* Request Form */}
          <div className="mb-6">
            <h2 className="text-xl font-bold text-foreground mb-2">طلب خدمة جديد</h2>
            <p className="text-muted-foreground mb-6">
              املأ النموذج أدناه لمعاينة كيفية عمل طلب الخدمة
            </p>
            
            <DemoRequestForm />
          </div>

          {/* Features Preview */}
          <Card className="mt-8">
            <CardHeader>
              <CardTitle className="text-lg">المزايا المتاحة في النسخة الكاملة</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-3">
                  <div className="flex items-start gap-3">
                    <div className="w-6 h-6 bg-green-100 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                      <i className="fas fa-camera text-green-600 text-xs"></i>
                    </div>
                    <div>
                      <h4 className="font-medium">رفع الصور</h4>
                      <p className="text-sm text-muted-foreground">رفع حتى 5 صور لتوضيح المشكلة</p>
                    </div>
                  </div>
                  
                  <div className="flex items-start gap-3">
                    <div className="w-6 h-6 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                      <i className="fas fa-bell text-blue-600 text-xs"></i>
                    </div>
                    <div>
                      <h4 className="font-medium">إشعارات فورية</h4>
                      <p className="text-sm text-muted-foreground">تنبيهات عند وصول عروض جديدة</p>
                    </div>
                  </div>
                  
                  <div className="flex items-start gap-3">
                    <div className="w-6 h-6 bg-purple-100 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                      <i className="fas fa-comments text-purple-600 text-xs"></i>
                    </div>
                    <div>
                      <h4 className="font-medium">تواصل مباشر</h4>
                      <p className="text-sm text-muted-foreground">دردشة مع المقاولين واستلام العروض</p>
                    </div>
                  </div>
                </div>
                
                <div className="space-y-3">
                  <div className="flex items-start gap-3">
                    <div className="w-6 h-6 bg-orange-100 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                      <i className="fas fa-star text-orange-600 text-xs"></i>
                    </div>
                    <div>
                      <h4 className="font-medium">تقييمات موثوقة</h4>
                      <p className="text-sm text-muted-foreground">عرض تقييمات العملاء السابقين</p>
                    </div>
                  </div>
                  
                  <div className="flex items-start gap-3">
                    <div className="w-6 h-6 bg-red-100 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                      <i className="fas fa-shield-alt text-red-600 text-xs"></i>
                    </div>
                    <div>
                      <h4 className="font-medium">ضمان الجودة</h4>
                      <p className="text-sm text-muted-foreground">مقاولون معتمدون وخدمة عملاء متاحة</p>
                    </div>
                  </div>
                  
                  <div className="flex items-start gap-3">
                    <div className="w-6 h-6 bg-teal-100 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                      <i className="fas fa-clock text-teal-600 text-xs"></i>
                    </div>
                    <div>
                      <h4 className="font-medium">متابعة الحالة</h4>
                      <p className="text-sm text-muted-foreground">متابعة تقدم العمل وتحديثات مستمرة</p>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}