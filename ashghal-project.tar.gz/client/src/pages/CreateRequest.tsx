import AppLayout from "../components/Layout/AppLayout";
import RequestForm from "../components/Requests/RequestForm";

export default function CreateRequest() {
  return (
    <AppLayout>
      <div className="max-w-4xl mx-auto" data-testid="create-request-page">
        <div className="mb-6">
          <h1 className="text-2xl font-bold text-foreground mb-2">طلب خدمة جديد</h1>
          <p className="text-muted-foreground">
            املأ النموذج أدناه لطلب خدمة من أحد مقاولينا المعتمدين
          </p>
        </div>
        
        <RequestForm />
      </div>
    </AppLayout>
  );
}
