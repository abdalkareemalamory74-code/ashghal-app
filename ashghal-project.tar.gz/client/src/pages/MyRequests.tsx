import { useState } from "react";
import { Link } from "wouter";
import { useRequests } from "../context/RequestsContext";
import AppLayout from "../components/Layout/AppLayout";
import RequestCard from "../components/Requests/RequestCard";
import RequestDetailModal from "../components/Requests/RequestDetailModal";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ServiceRequest } from "../context/RequestsContext";

export default function MyRequests() {
  const { myRequests, loading } = useRequests();
  const [selectedRequest, setSelectedRequest] = useState<ServiceRequest | null>(null);
  const [statusFilter, setStatusFilter] = useState<string>("all");

  const filteredRequests = myRequests;

  if (loading) {
    return (
      <AppLayout>
        <div className="flex items-center justify-center h-64">
          <div className="text-center">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-4"></div>
            <p className="text-muted-foreground">جاري تحميل الطلبات...</p>
          </div>
        </div>
      </AppLayout>
    );
  }

  return (
    <AppLayout>
      <div className="space-y-6" data-testid="my-requests-page">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-foreground mb-2">طلباتي</h1>
            <p className="text-muted-foreground">
              إدارة ومتابعة جميع طلبات الخدمة الخاصة بك
            </p>
          </div>
          <Button asChild data-testid="button-create-request">
            <Link href="/create-request">
              <i className="fas fa-plus ml-2"></i>
              طلب جديد
            </Link>
          </Button>
        </div>


        {/* Requests List */}
        <Card>
          <CardHeader>
            <CardTitle>طلباتك</CardTitle>
          </CardHeader>
          <CardContent>
            {filteredRequests.length === 0 ? (
              <div className="text-center py-12" data-testid="no-requests">
                <i className="fas fa-clipboard-list text-6xl text-muted-foreground mb-6"></i>
                <h3 className="text-lg font-semibold text-foreground mb-2">
                  لا توجد طلبات بعد
                </h3>
                <p className="text-muted-foreground mb-6">
                  ابدأ بإنشاء طلب خدمة جديد للحصول على المساعدة التي تحتاجها
                </p>
                <Button asChild>
                  <Link href="/create-request">إنشاء طلب جديد</Link>
                </Button>
              </div>
            ) : (
              <div className="space-y-4" data-testid="requests-list">
                {filteredRequests.map((request) => (
                  <RequestCard
                    key={request.id}
                    request={request}
                    onViewDetails={setSelectedRequest}
                  />
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      <RequestDetailModal
        request={selectedRequest}
        isOpen={!!selectedRequest}
        onClose={() => setSelectedRequest(null)}
      />
    </AppLayout>
  );
}
