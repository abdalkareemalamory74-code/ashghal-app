import type { Express } from "express";
import { createServer, type Server } from "http";

export async function registerRoutes(app: Express): Promise<Server> {
  // Firebase handles all data operations directly from client-side
  // No backend API routes needed for this MVP
  
  const httpServer = createServer(app);

  return httpServer;
}
